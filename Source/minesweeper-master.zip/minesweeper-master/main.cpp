#include <iostream>
#include "board.hpp"
#include <chrono>

using namespace std;

int main(int argc, char const *argv[]) {
  board mineBoard(16, 30);

  // mineBoard.printBoard();
  // cout << endl;
  int openRow, openColumn;
  cin >> openRow >> openColumn;
  std::chrono::high_resolution_clock::time_point t1 = std::chrono::high_resolution_clock::now();
  // mineBoard.open(1, 1);
  // mineBoard.printBoard();
  while (mineBoard.open(openRow, openColumn) >= 0 || !mineBoard.isFinished()) {
    mineBoard.printBoard();
    cin >> openRow >> openColumn;
  }
  std::chrono::high_resolution_clock::time_point t2 = std::chrono::high_resolution_clock::now();

  auto duration = std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count();

  cout << duration / 1000 << "sec" << duration % 1000 << "milisec" << endl;

  return 0;
}
