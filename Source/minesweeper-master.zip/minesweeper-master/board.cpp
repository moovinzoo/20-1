#include "board.hpp"
#include <iostream>
#include <stdlib.h>

board::board (int row, int column) {
  this->row = row;
  this->column = column;

  isOpen = (bool **)malloc(sizeof (bool *) * row);
  content = (int **)malloc(sizeof (int *) * row);
  for (int i=0; i<row; i++) {
    isOpen[i] = (bool *)malloc(sizeof(bool) * column);
    content[i] = (int *)malloc(sizeof(int) * column);
    for (int j=0; j<column; j++) {
      isOpen[i][j] = false;
      content[i][j] = 0;
    }
  }
}

board::~board () {
  for (int i=0; i<row; i++) {
    free(isOpen[i]);
    free(content[i]);
  }
  free(isOpen);
  free(content);
}
void board::printBoard() {
  for (int i=0; i<row; i++) {
    for (int j=0; j<column; j++) {
      /*if(isOpen[i][j]) {
          std::cout << 'o';
      } else {
          std::cout << 'c';
      }*/
      std::cout << content[i][j];
    }
    std::cout << std::endl;
  }
}
int board::open(int row, int column) {
  isOpen[row][column] = true;
  return content[row][column];
}

bool board::isFinished() {

}
