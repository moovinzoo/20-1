
class board {
private:
  bool ** isOpen;
  int ** content;
  int row;
  int column;

public:
  board (int row, int column);
  virtual ~board ();
  void printBoard();
  int open(int row, int column);
  bool isFinished();
  //void close(int row, int column);

};
