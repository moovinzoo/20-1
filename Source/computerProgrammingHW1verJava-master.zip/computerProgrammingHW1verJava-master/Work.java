package phoneBook;

public class Work extends Person {
	public Work(String firstName, String lastName, String phoneNumber, String team) {
		super(firstName, lastName, phoneNumber);
		this.team = team;
	}
	
	public void setTeam(String team) {
		this.team = team;
	}
	
	public String getTeam() {
		return this.team;
	}
	
	@Override
	public void print() {
		System.out.println(this.getFirstName() + " " + this.getLastName() + "_" + this.getPhoneNumber() + "_" + this.team);
	}
	
	@Override
	public boolean isError() {
		if (super.isError()) return true;
		
		return false;
	}
	
	
	private String team;
}