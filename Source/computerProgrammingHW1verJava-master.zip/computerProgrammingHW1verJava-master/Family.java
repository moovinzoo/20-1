package phoneBook;

public class Family extends Person {
	public Family(String firstName, String lastName, String phoneNumber, String birthDay) {
		super(firstName, lastName, phoneNumber);
		this.birthday = new MyDate(birthDay);
	}
	
	public int dDay() {
		return MyDate.dDay(this.birthday);
	}
	
	public void setBirthday(String birthday) {
		this.birthday = new MyDate(birthday);
	}
	
	public String getBirthday() {
		return this.birthday.getDatef();
	}
	
	@Override
	public void print() {
		System.out.print(this.getFirstName() + " " + this.getLastName());
		System.out.println("_" + this.getPhoneNumber() + "_" + this.getBirthday() + "_" + this.dDay());
	}
	
	@Override
	public boolean isError() {
		if (super.isError()) {
			return true;
		}
		if (this.birthday.isError()) {
			return true;
		}
		return false;
	}
	
	private MyDate birthday;
}
