package phoneBook;

public class Friend extends Person {
	public Friend(String firstName, String lastName, String phoneNum, int age) {
		super(firstName, lastName, phoneNum);
		this.age = age;
	}
	
	public void setAge(int age) {
		if (age > 0) {
			this.age = age;
		} else {
			this.age = -1;
		}
	}
	
	public int getAge() {
		return this.age;
	}
	
	@Override
	public void print() {
		System.out.println(this.getFirstName() + " " + this.getLastName() + "_" + this.getPhoneNumber() + "_" + this.age);
	}
	
	@Override
	public boolean isError() {
		if (super.isError()) {
			return true;
		}
		if (this.getAge() < 0) {
			return true;
		}
		return false;
	}
	
	private int age;
}
