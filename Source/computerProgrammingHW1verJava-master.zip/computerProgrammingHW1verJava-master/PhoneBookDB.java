package phoneBook;

import java.util.List;
import java.util.ArrayList;

public class PhoneBookDB {
	public PhoneBookDB() {
		phoneBook = new ArrayList<>();
	}
	
	public void add(Person input) {
		if (input.isError()) {
			System.out.println("INVALID INPUT FORMAT");
			return;
		}
		phoneBook.add(input);
		System.out.println("Successfully added new person.");
	}
	
	public void removeAt(int index) {
		if (index >= phoneBook.size() || index < 0) {
			System.out.println("Person does not exist!");
			return;
		}
		phoneBook.remove(index);
		System.out.println("A person is successfully deleted from the Phone Book!");
	}
	
	public void printAll() {
		
		for (int i=0; i<phoneBook.size(); i++) {
			System.out.print(i+1 + ". ");
			phoneBook.get(i).print();
		}
	}
	
	private List<Person> phoneBook;
}
