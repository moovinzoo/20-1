package phoneBook;

import java.lang.Math;


public class Person {
	public Person(String firstName, String lastName, String phoneNum) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumberInfo = toPhoneNumberInfo(phoneNum);
	}

	public Person(Person rhs) {
		this.firstName = rhs.firstName;
		this.lastName = rhs.lastName;
		this.phoneNumberInfo = rhs.phoneNumberInfo;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumberInfo = phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumberInfo = toPhoneNumberInfo(phoneNumber);
	}
	
	public String getFirstName() {
		return this.firstName;
	}
	
	public String getLastName() {
		return this.lastName;
	}
	
	public long getPhoneNumberInfo() {
		return this.phoneNumberInfo;
	}
	
	public int getLengthInfo() {
		long mask = (long)Math.pow(10.0, 18.0);  //1,000,000,000,000,000,000
												//9,223,372,036,854,775,807 == long.MAX_VALUE
		while (phoneNumberInfo / mask == 0) {
			mask = mask / 10;
		}
		mask = mask / 100;

		return (int)(phoneNumberInfo / mask);
	}

	public String getPhoneNumber() {

	    
	    long phoneNumberInfo = this.phoneNumberInfo;
	    
	    int lengthInfo = this.getLengthInfo();
	    
	    
	    int frontLength = lengthInfo / 100;         //3
	    int middleLength = lengthInfo % 100 / 10;   //4
	    int lastLength = lengthInfo % 10;           //4
	    
	    long firstMask = (long)Math.pow(10.0, (double)(frontLength + middleLength + lastLength));
	    long secondMask = (long)Math.pow(10.0, (double)(middleLength + lastLength));
	    long thirdMask = (long)Math.pow(10.0, (double)(lastLength));
	    
	    StringBuilder sb = new StringBuilder("");
	    
	    String firstNumber = String.valueOf(((int)(phoneNumberInfo % firstMask / secondMask)));  //10
	    String secondNumber = String.valueOf((int)(phoneNumberInfo % secondMask / thirdMask)); //2459
	    String thirdNumber = String.valueOf(((int)(phoneNumberInfo % thirdMask)));               //2062
	    
	    //0 handling;
	    for (int i=0; i<frontLength - firstNumber.length(); i++) {//for 'number of 0' times
	    	sb.append("0");
	        //result += "0";
	    }
	    sb.append(firstNumber);
	    //result += firstNumber;
	    
	    sb.append("-");
	    //result += "-";
	    
	    for (int i=0; i<middleLength - secondNumber.length(); i++) {
	    	sb.append("0");
	        //result += "0";
	    }
	    sb.append(secondNumber);
	    //result += secondNumber;
	    
	    sb.append("-");
	    //result += "-";
	    
	    for (int i=0; i<lastLength - thirdNumber.length(); i++) {
	    	sb.append("0");
	        //result += "0";
	    }
	    sb.append(thirdNumber);
	    //result += thirdNumber;
	    
	    return sb.toString();
	}
	
	
	
	public static long toPhoneNumberInfo(String phoneNum) {
		if (!phoneNum.contains("-")) {
			return -1l;
		}
		
		if (phoneNum.indexOf('-') == phoneNum.lastIndexOf('-')) {//not implemented yet
			return -1l;
		}
		
		if (phoneNum.length() < 11 || phoneNum.length() > 13) {
			return -1l;
		}
		
		int firstIndex = phoneNum.indexOf('-');
		int lastIndex = phoneNum.lastIndexOf('-');
		
		int firstLength = firstIndex;
		int middleLength = lastIndex - firstIndex - 1;
		int lastLength = phoneNum.length() - lastIndex - 1;
		
		long phoneNumberInfo = (long)firstLength;
		
		phoneNumberInfo *= 10;
		phoneNumberInfo += middleLength;
		
		phoneNumberInfo *= 10;
		phoneNumberInfo += lastLength;
		
		phoneNumberInfo *= (long)Math.pow(10.0, (double)firstLength);
		phoneNumberInfo += Long.parseLong(phoneNum.substring(0, firstLength));
		
		phoneNumberInfo *= (long)Math.pow(10.0, (double)middleLength);
		phoneNumberInfo += Long.parseLong(phoneNum.substring(firstLength + 1, firstLength + 1 + middleLength));
		
		phoneNumberInfo *= (long)Math.pow(10.0, (double)lastLength);
		phoneNumberInfo += Long.parseLong(phoneNum.substring(firstLength + middleLength + 2, firstLength + middleLength + 2 + lastLength));
		
		return phoneNumberInfo;
		
	}
	
	public boolean isError() {
		if (this.getPhoneNumberInfo() == -1l) {
	        return true;
	    }
	    return false;
	}
	
	public void print() {
		System.out.println(this.firstName + " " + this.lastName + "_" + this.getPhoneNumber());
	}
	
	private String firstName;
	private String lastName;
	private long phoneNumberInfo;
}
