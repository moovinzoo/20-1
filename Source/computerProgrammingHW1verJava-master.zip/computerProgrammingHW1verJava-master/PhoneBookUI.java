package phoneBook;

import java.util.Scanner;

public class PhoneBookUI {
	public PhoneBookUI() {
		;
	}
	
	public int run(PhoneBookDB pbDB) {
		Scanner scanner = new Scanner(System.in);
		String menuSelect;
		
		while (true) {
			printMenu();
			printPrompt();
			
			menuSelect = scanner.nextLine();
			
			if (menuSelect.equals("quit")) {
				System.out.println("Bye.");
				break;
			}
			
			if (!(menuSelect.length() == 1 && Character.isDigit(menuSelect.charAt(0)))) {
				printErrorMsg();
				continue;
			}
			switch (Integer.parseInt(menuSelect)) {
			case 1: {//add
                int typeSelect;
                printType();
                printPrompt();
                typeSelect = scanner.nextInt();
                
                String firstName;
                String lastName;
                String phoneNumber;
                
                switch (typeSelect) {
                    case 1: {//Person
                        System.out.print("Name: ");
                        firstName = scanner.next();
                        lastName = scanner.next();
                        scanner.nextLine();
                        System.out.print("Phone_number: ");
                        phoneNumber = scanner.nextLine();
                        Person newPerson = new Person(firstName, lastName, phoneNumber);
                        pbDB.add(newPerson);
                        break;
                    }
                    case 2: {//Work
                        String team;
                        System.out.print("Name: ");
                        firstName = scanner.next();
                        lastName = scanner.next();
                        scanner.nextLine();
                        System.out.print("Phone_number: ");
                        phoneNumber = scanner.nextLine();
                        System.out.print("team: ");
                        team = scanner.nextLine();
                        Work newWorkMember = new Work(firstName, lastName, phoneNumber, team);
                        pbDB.add(newWorkMember);
                        break;
                    }
                    case 3: {//Family
                        String birthday;
                        System.out.print("Name: ");
                        firstName = scanner.next();
                        lastName = scanner.next();
                        scanner.nextLine();
                        System.out.print("Phone_number: ");
                        phoneNumber = scanner.nextLine();
                        System.out.print("Birthday: ");
                        birthday = scanner.nextLine();
                        Family newFamilyMember = new Family(firstName, lastName, phoneNumber, birthday);
                        pbDB.add(newFamilyMember);
                        break;
                    }
                    case 4: {//Friend
                        int age;
                        System.out.print("Name: ");
                        firstName = scanner.next();
                        lastName = scanner.next();
                        scanner.nextLine();
                        System.out.print("Phone_number: ");
                        phoneNumber = scanner.nextLine();
                        System.out.print("age: ");
                        age = scanner.nextInt();
                        scanner.nextLine();
                        Friend newFriend = new Friend(firstName, lastName, phoneNumber, age);
                        pbDB.add(newFriend);
                        break;
                    }
                    default:
                        printErrorMsg();
                        break;
                }
                
                break;
            }
            case 2: {//remove
                int removeIndex;
                System.out.print("Enter Index of person: ");
                removeIndex = scanner.nextInt();
                scanner.nextLine();
                pbDB.removeAt(removeIndex-1);//invert user-index(start at 1) to C-index (start at 0) 
                break;
            }
            case 3: {//print
            	System.out.println("Phone Book Print");
                pbDB.printAll();
                break;
            }
            default:
                printErrorMsg();
                break;

			}
		}
		scanner.close();
		return 0;
	}
	
	public static void printMenu() {
		printPrompt();System.out.println("");
		System.out.println("Phone Book");
		System.out.println("1. Add person");
		System.out.println("2. Remove person");
		System.out.println("3. Print phone book");
	}
	
	public static void printType() {
		System.out.println("Select Type");
		System.out.println("1. Person");
		System.out.println("2. Work");
		System.out.println("3. Family");
		System.out.println("4. Friend");
	}
	
	public static void printPrompt() {
		System.out.print("CP-2015-12139>");
	}
	
	public static void printErrorMsg() {
		System.out.println("INPUT ERROR");
		System.out.println("input appropriate index");
	}
	
}
