please visit

https://github.com/lightb0x/computerProgrammingHW1verJava.git

for development history or in case of data loss.


*submitted program is 5th commit version.




to run this program, first remove first line of all .java files(package line)
then enter
“javac *.java” and
“java PhoneBook”
into linux console.

// this program is based on Java version 8.

enter “quit” to end process.

date format is YYMMDD
phone number format is [n digit]-[n digit]-[n digit] total length of from 11 to 13 including dash.