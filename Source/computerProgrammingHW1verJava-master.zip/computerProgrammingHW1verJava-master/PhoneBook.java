package phoneBook;

public class PhoneBook {

	public static void main(String[] args) {
		PhoneBookDB pbDB = new PhoneBookDB();
		PhoneBookUI pbUI = new PhoneBookUI();
		
		pbUI.run(pbDB);
		
		return;
	}

}
