package phoneBook;

import java.lang.Character;
import java.util.Calendar;

public class MyDate {
	public MyDate(String rhs) {
		if (MyDate.isFormatted(rhs)) {
			datef = rhs;
		} else {
			datef = ERROR_MSG;
		}
	}
	public MyDate(int year, int month, int day) {
		if (year < 0) {
			datef = ERROR_MSG;
			return;
		}
		if (month < 0 || month > 12) {
			datef = ERROR_MSG;
			return;
		}
		if (day < 0 || day > dayOfMonth(year, month)) {
			datef = ERROR_MSG;
			return;
		}

		this.setDatef(year, month, day);
	}

	public void increment() {
		int nowDay = this.getDay();
		int nowMonth = this.getMonth();
		int nowYear = this.getYear();

		nowDay++;
		if (nowDay > dayOfMonth(nowYear, nowMonth)) {
			nowDay = 1;
			nowMonth++;
			if (nowMonth > 12) {
				nowMonth = 1;
				nowYear++;
                if (nowYear == 100) {
                    nowYear = 0;
                }
			}
		}
		this.setDatef(nowYear, nowMonth, nowDay);
	}

	public boolean isSame(MyDate rhs) {
		if (this.getDay() == rhs.getDay() && this.getMonth() == rhs.getMonth()) {
			return true;
		}
		return false;
	}

	public int getYear() {
		if (datef.equals(ERROR_MSG)) {
			return -1;
		}
		return Integer.parseInt(this.datef.substring(YEAR_INDEX, YEAR_LENGTH));
	}

	public int getMonth() {
		if (datef.equals(ERROR_MSG)) return -1;

		return Integer.parseInt(this.datef.substring(MONTH_INDEX, YEAR_LENGTH + MONTH_LENGTH));
	}

	public int getDay() {
		if (datef.equals(ERROR_MSG)) return -1;

		return Integer.parseInt(this.datef.substring(DAY_INDEX, YEAR_LENGTH + MONTH_LENGTH + DAY_LENGTH));
	}

	public String getDatef() {
		return this.datef;
	}

	public void setDatef(String rhs) {
		this.datef = rhs;
	}
	
	public String toDatef(int year, int month, int day) {
		StringBuilder sb = new StringBuilder("");

		if (year == 0) {
			sb.append("00");
		} else if (year < 10) {
			sb.append("0");
			sb.append(year);
		} else {
			sb.append(year);
		}

		if (month == 0) {
			sb.append("00");
		} else if (month < 10) {
			sb.append("0");
			sb.append(month);
		} else {
			sb.append(month);
		}

		if (day == 0) {
			sb.append("00");
		} else if (day < 10) {
			sb.append("0");
			sb.append(day);
		} else {
			sb.append(day);
		}

		return sb.toString();
	}

	public void setDatef(int year, int month, int day) {
		this.datef = toDatef(year, month, day);
	}


	public static int dDay(MyDate specialDate) {
		Calendar today = Calendar.getInstance();

		int nowYear = today.get(Calendar.YEAR) % 100;
		int nowMonth = (today.get(Calendar.MONTH) + 1);
		int nowDay = today.get(Calendar.DAY_OF_MONTH);

		int specialMonth = specialDate.getMonth();
		int specialDay = specialDate.getDay();

		int result = 0;

		//dDay calculation
		MyDate nowDate = new MyDate(nowYear, nowMonth, nowDay);
		while (!nowDate.isSameDay(specialMonth, specialDay)) {
			nowDate.increment();
			result++;
		}

		return result;
	}

	public static int dayOfMonth(int year, int month) {
		if (year < 0) {
			return -1;
		}

		switch (month) {
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			return 31;

		case 4:
		case 6:
		case 9:
		case 11:
			return 30;

		case 2:
			if (isLeapYear(year)) return 29;
			return 28;

		default:
			return -1;
		}
	}

	public static boolean isLeapYear(int year) {
		if (year < 0) {
			return false;
		}

		if (year % 4 == 0) {
			if (year % 100 == 0) {
				if (year % 400 == 0) {
					return true;
				}
				return false;
			}
			return true;
		}
		return false;
	}

	public boolean isSameDay(int month, int day) {
		if (this.getDay() == day && this.getMonth() == month) {
			return true;
		}
		return false;
	}

	public static boolean isFormatted(String date) {

		if (date.length() != YEAR_LENGTH + MONTH_LENGTH + DAY_LENGTH) {
			return false;
		}

		for (int i = 0; i<date.length(); i++) {
			if (!Character.isDigit(date.charAt(i))) {
				return false;
			}
		}

		int year = Integer.parseInt(date.substring(YEAR_INDEX, YEAR_LENGTH));
		int month = Integer.parseInt(date.substring(MONTH_INDEX, YEAR_LENGTH + MONTH_LENGTH));
		int day = Integer.parseInt(date.substring(DAY_INDEX, YEAR_LENGTH + MONTH_LENGTH + DAY_LENGTH));

		if (year < 0) {
			return false;
		}
		if (month < 0 || month > 12) {
			return false;
		}
		if (day < 0 || day > dayOfMonth(year, month)) {
			return false;
		}
		return true;

	}

	public boolean isError() {
		if (datef.equals(ERROR_MSG)) return true;
		return false;
	}

	private static final int YEAR_INDEX = 0;
	private static final int YEAR_LENGTH = 2;
	private static final int MONTH_INDEX = 2;
	private static final int MONTH_LENGTH = 2;
	private static final int DAY_INDEX = 4;
	private static final int DAY_LENGTH  = 2;
	private static final String ERROR_MSG = "INAPPROPRIATE INPUT, FORMAT YYMMDD";

	private String datef;
}
