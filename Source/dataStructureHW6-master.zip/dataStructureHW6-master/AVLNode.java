public class AVLNode<K extends Comparable<K>, V> {
    
    private K key;
    private V value;
    private AVLNode<K, V> parent;
    private AVLNode<K, V> left;
    private AVLNode<K, V> right;
    private int height = 0;
    
    public AVLNode(K key, V value) {
        this.key = key;
        this.value = value;
        parent = null;
        left = null;
        right = null;
        height = 1;
    }
    
    public AVLNode(K key, AVLNode<K, V> parent, V value) {
        this.key = key;
        this.value = value;
        this.parent = parent;
        this.left = null;
        this.right = null;
        this.height = 1;
    }
    
    public AVLNode(K key, AVLNode<K, V> parent, AVLNode<K, V> left, V value) {
        this.key = key;
        this.value = value;
        this.parent = parent;
        this.left = left;
        this.right = null;
        this.height = left.height + 1;
    }
    
    public AVLNode(K key, AVLNode<K, V> parent, AVLNode<K, V> left, AVLNode<K, V> right, V value) {
        this.key = key;
        this.value = value;
        this.parent = parent;
        this.left = left;
        this.right = right;
        this.height = (left.height > right.height) ? left.height + 1 : right.height + 1;
    }
    
    public boolean equals(AVLNode<K, V> rhs) {
        if (rhs == null) return false;
        if (!this.key.equals(rhs.key)) {
            return false;
        }
        
        return true;
    }
    
    public void connect(AVLNode<K, V> child, boolean isRight) {
        if (child != null) {
            child.setParent(this);
        }
        
        if (isRight) {
            this.setRight(child);
        } else {
            this.setLeft(child);
        }
    }
    /*
    public void swap(AVLNode<K, V> lhs, AVLNode<K, V> rhs) {
        K temp = lhs.key;
        lhs.key = rhs.key;
        rhs.key = temp;
    }*/
    
    public K getKey() {
        return key;
    }
    
    public V getValue() {
        return value;
    }
    
    public int getHeight() {
        return height;
    }
    
    public AVLNode<K, V> getParent() {
        return parent;
    }
    
    public AVLNode<K, V> getLeft() {
        return left;
    }
    
    public AVLNode<K, V> getRight() {
        return right;
    }
    
    public void setKey(K key) {
        if (key != null) {
            this.key = key;
        }
    }
    
    public void setValue(V value) {
        if (value != null) {
            this.value = value;
        }
    }
    
    public void setHeight() {
        if (left == null && right == null) {
            height = 1;
        } else if (left == null) {
            height = right.getHeight() + 1;
        } else if (right == null) {
            height = left.getHeight() + 1;
        } else {
            height = left.getHeight() > right.getHeight() ?
                    left.getHeight() + 1 : right.getHeight() + 1;
        }
        
    }
    
    public void setHeight(int height) {
        this.height = height;
    }
    
    public void setParent(AVLNode<K, V> parent) {
        this.parent = parent;
    }
    
    public void setLeft(AVLNode<K, V> left) {
        if (left != null) {
            left.setParent(this);
        }
        this.left = left;
    }
    
    public void setRight(AVLNode<K, V> right) {
        if (right != null) {
            right.setParent(this);
        }
        this.right = right;
    }
    
    public boolean needRotation() {
        return this.needRightRotation() || this.needLeftRotation();
    }
    public boolean needRightRotation() {
        //error handling for dummy head
        if (parent == null) {
            return false;
        }
        if (left == null && right == null) {
            return false;
        } else if (left == null) {
            return false;
        } else if (right == null) {
            return left.height > 1;
        }
        return left.height - right.height > 1;
    }
    public boolean needLeftRotation() {
        if (parent == null) {
            return false;
        }
        if (left == null && right == null) {
            return false;
        } else if (left == null) {
            return right.height > 1;
        } else if (right == null) {
            return false;
        }
        return right.height - left.height > 1;
    }
}