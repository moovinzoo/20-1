public class Edge {
    private Vertex from;
    private Vertex to;
    private double weight;
    private boolean isTransfer;
    
    public Edge(Vertex from, Vertex to, double weight, boolean isTransfer) {
        this.from = from;
        this.to = to;
        this.weight = weight;
        this.isTransfer = isTransfer;
    }
    
    public double getWeight() {
        return weight;
    }
    public Vertex getTo() {
        return to;
    }
    public Vertex getFrom() {
        return from;
    }
    public boolean getTransfer() {
        return isTransfer;
    }
    
    public void setWeight(double weight) {
        this.weight = weight;
    }
    public void setTo(Vertex to) {
        this.to = to;
    }
    public void setFrom(Vertex from) {
        this.from = from;
    }
    public void setTransfer(boolean isTransfer) {
        this.isTransfer = isTransfer;
    }
    
    public boolean equals(Edge rhs) {
        return from.equals(rhs.getFrom()) && to.equals(rhs.getTo());
    }
}