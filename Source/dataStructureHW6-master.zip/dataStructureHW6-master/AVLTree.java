public class AVLTree<K extends Comparable<K>, V> {
    private AVLNode<K, V> dummy;
    private long size;
    
    public AVLTree() {
        dummy = new AVLNode<K, V>(null, null);
    }
    
    public AVLTree(AVLNode<K, V> head) {
        //dummy's left child is AVLTree start.
        dummy = new AVLNode<K, V>(null, null, head, null);
    }
    
    public int getHeight() {
        return dummy.getHeight()-1;
    }
    
    //rotate : call when target.needRotation() is true
    public void rotate(AVLNode<K, V> target) {
        AVLNode<K, V> targetParent = target.getParent();
        boolean isRight;
        if (targetParent.getLeft() == target) {
            isRight = false;
        } else if (targetParent.getRight() == target) {
            isRight = true;
        } else {
            System.out.println("ROTATE() ERROR : inappropriate parent");
            return;
        }
        
        if (target.needRightRotation()) {
            AVLNode<K, V> targetLeft = target.getLeft();
            // NullPointerException resolved?
            if (targetLeft.getRight() == null || targetLeft.getLeft() != null &&
                targetLeft.getLeft().getHeight() > targetLeft.getRight().getHeight()) {
                //LL case
                
                targetParent.connect(targetLeft, isRight);
                target.connect(targetLeft.getRight(), false);
                targetLeft.connect(target, true);
                
                targetLeft.getLeft().setHeight();
                target.setHeight();
                targetLeft.setHeight();
            } else {
                //LR case
                AVLNode<K, V> LR = targetLeft.getRight();
                
                targetParent.connect(LR, isRight);
                targetLeft.connect(LR.getLeft(), true);
                target.connect(LR.getRight(), false);
                LR.connect(targetLeft, false);
                LR.connect(target, true);
                
                target.setHeight();
                targetLeft.setHeight();
                LR.setHeight();
            }
        } else if (target.needLeftRotation()) {
            AVLNode<K, V> targetRight = target.getRight();
            // resolved?
            if (targetRight.getRight() == null || targetRight.getLeft() != null &&
                targetRight.getLeft().getHeight() > targetRight.getRight().getHeight()) {
                //RL case
                AVLNode<K, V> RL = targetRight.getLeft();
                
                targetParent.connect(RL, isRight);
                target.connect(RL.getLeft(), true);
                targetRight.connect(RL.getRight(), false);
                RL.connect(target, false);
                RL.connect(targetRight, true);

                target.setHeight();
                targetRight.setHeight();
                RL.setHeight();
            } else {
                //RR case
                targetParent.connect(targetRight, isRight);
                target.connect(targetRight.getLeft(), true);
                targetRight.connect(target, false);

                targetRight.getRight().setHeight();
                target.setHeight();
                targetRight.setHeight();
            }
        } else {
            //inappropriate method call
            System.out.println("INAPPROPRIATE ROTATE() CALL");
            return;
        }
    }
    
    //insert : if already exist, return that.
    public AVLNode<K, V> insert(K key, V value) {
        AVLNode<K, V> searchResult = search(key);
        
        if (searchResult == null) {
            dummy.setLeft(new AVLNode<K, V>(key, dummy, value));
            searchResult = dummy.getLeft();
            return null;
        }
        
        if (searchResult.getKey().compareTo(key) > 0) {
            searchResult.setLeft(new AVLNode<K, V>(key, searchResult, value));
        } else if (searchResult.getKey().compareTo(key) < 0) {
            searchResult.setRight(new AVLNode<K, V>(key, searchResult, value));
        } else {//already exist
            return searchResult;
        }
        
        //update height information & do rotation when needed
        AVLNode<K, V> cursor = searchResult;
        while (cursor != dummy) {
            cursor.setHeight();
            if (cursor.needRotation()) {
                this.rotate(cursor);
                break;//??
            }
            cursor = cursor.getParent();
        }
        size++;
        return null;
    }
    
    //search : return last reference if not found
    //          if found, return reference of that
    //          return null when tree is empty
    public AVLNode<K, V> search(K key) {
        AVLNode<K, V> prev = dummy;
        AVLNode<K, V> curr;
        
        if (dummy.getLeft() == null) {
            return null;
        } else {
            curr = dummy.getLeft();
        }
        
        while (curr.getKey().compareTo(key) != 0) {
            prev = curr;
            
            if (curr.getKey().compareTo(key) > 0) {
                curr = curr.getLeft();
            } else {
                curr = curr.getRight();
            }
            
            if (curr == null) {
                return prev;
            }
        }
        return curr;
    }
    
    //return null when not found or tree is empty
    public AVLNode<K, V> explicitSearch(K key) {
        AVLNode<K, V> curr;
        
        if (dummy.getLeft() == null) {
            return null;
        } else {
            curr = dummy.getLeft();
        }
        
        while (curr.getKey().compareTo(key) != 0) {
            
            if (curr.getKey().compareTo(key) > 0) {
                curr = curr.getLeft();
            } else {
                curr = curr.getRight();
            }
            
            if (curr == null) {
                return null;
            }
        }
        return curr;
    }
    
    public AVLNode<K, V> getHead() {
        if (dummy == null) {
            return null;
        }
        return dummy.getLeft();
    }
    public long size() {
        return size;
    }
/*
    //when tree is empty, do nothing
    // when item not found, do nothing
    // when item found, delete
    public void delete(K key) {
        AVLNode<K, V> target = search(key);
        
        if (target == null) {
            return;
        }
        
        if (target.getKey().compareTo(key) == 0) {
            //deletion process
            AVLNode<K, V> replace = getMost(target.getLeft());
            AVLNode<K, V> replaceParent = replace.getParent();
            target.setKey(replace.getKey());
            replaceParent.setRight(replace.getLeft());
            
            AVLNode<K, V> cursor = replaceParent;
            while (cursor != dummy) {
                cursor.setHeight();
                if (cursor.needRotation()) {
                    rotate(cursor);
                    break;
                }
                cursor = cursor.getParent();
            }
        } else {
            return;
        }
    }
    
    public AVLNode<K, V> getMost(AVLNode<K, V> cursor) {
        while (cursor.getRight() != null) {
            cursor = cursor.getRight();
        }
        return cursor;
    }*/
}