import java.io.*;
import java.util.Scanner;

public class Subway {
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("INVALID INPUT : use");
            System.out.println("java Subway [data]");
            return;
        }
        
        BufferedReader subwayFile;
        try {
            subwayFile = new BufferedReader(new FileReader(args[0]));
        } catch (IOException e) {
            System.out.println(e.toString());
            return;
        }
        
        String oneLineInput;
        
        Graph subwayGraph = new Graph();
        
        try {
            while ((oneLineInput = subwayFile.readLine()) != null) {
                //file's first half processing
                if (oneLineInput.equals("")) break;
                
                int firstSpaceIndex = oneLineInput.indexOf(' ');
                int lastSpaceIndex = oneLineInput.lastIndexOf(' ');
                
                // parse one line to three substring's : unique code, station name, line number
                String number = oneLineInput.substring(0, firstSpaceIndex);
                String name = oneLineInput.substring(firstSpaceIndex+1, lastSpaceIndex);
                String line = oneLineInput.substring(lastSpaceIndex+1, oneLineInput.length());
                
                subwayGraph.addStation(number, name, line);
            }
            
            while ((oneLineInput = subwayFile.readLine()) !=  null) {
                //file's second half processing
                int firstSpaceIndex = oneLineInput.indexOf(' ');
                int lastSpaceIndex = oneLineInput.lastIndexOf(' ');
                
                String fromNumber = oneLineInput.substring(0, firstSpaceIndex);
                String toNumber = oneLineInput.substring(firstSpaceIndex+1, lastSpaceIndex);
                double time = Double.parseDouble(oneLineInput.substring(lastSpaceIndex+1, oneLineInput.length()));
                
                subwayGraph.addInformation(fromNumber, toNumber, time);
            }
        } catch(IOException e) {
            System.out.println(e.toString());
        }
        
        try {
            subwayFile.close();
        } catch (IOException e) {
            System.out.println(e.toString());
            return;
        }
        
        //convert
        HashGraph subwayHash = new HashGraph(subwayGraph);
        
        //search
        Scanner scanner = new Scanner(System.in);
        
        String tmpIn;
        while (!(tmpIn = scanner.nextLine()).equals("QUIT")) {
            int spaceIndex = tmpIn.indexOf(' ');
            String from = tmpIn.substring(0, spaceIndex);
            String to = tmpIn.substring(spaceIndex + 1, tmpIn.length());
            System.out.println(subwayHash.shortestPath(from, to));
        }
    }
}