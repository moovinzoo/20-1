import java.util.Hashtable;
import java.util.Vector;
import java.util.Set;

public class HashGraph {
    private Hashtable<String, Vector<String>> nameTable;
    private Hashtable<String, Vertex> numberTable;
    
    public HashGraph(Graph rhs) {
        //nameTable = rhs;
        nameTable = new Hashtable<String, Vector<String>>((int)rhs.getNameTree().size() * 2);
        numberTable = new Hashtable<String, Vertex>((int)rhs.getNumberTree().size() * 2);
        
        nameCopy(nameTable, rhs.getNameTree());
        numberCopy(numberTable, rhs.getNumberTree());
    }
    
    public String shortestPath(String fromName, String toName) {
        if (fromName.equals(toName)) {
            return fromName + '\n' + "0";
        }
        
        FibonacciHeap<Vertex> includedSet = new FibonacciHeap<>();
        
        Vector<String> startStation = searchByName(fromName);
        Vector<String> destinationStation = searchByName(toName);
        
        for (int i=0; i<startStation.size(); i++) {
            String stationNumber = startStation.elementAt(i);
            Vertex station = searchByNumber(stationNumber);
            
            station.setVisited(true);
            station.setMinTime(0);
            includedSet = FibonacciHeap.merge(includedSet, getFibHeapFrom(station));
        }
        
        Vertex closest = includedSet.min().getValue();
        
        //pathfinding
        while (!isEnd(destinationStation, closest.getNumber())) {
            double weight = includedSet.dequeueMin().getPriority();
            
            closest.setMinTime(weight);
            closest.setVisited(true);
            
            Vector<String> nameSearchResult = searchByName(closest.getName());
            int size = nameSearchResult.size();
            for (int i=0; i<size; i++) {
                Vertex searchResult = searchByNumber(nameSearchResult.elementAt(i));
                if (closest.equals(searchResult)) continue;
                if (searchResult.getVisited()) continue;
                //append searchResult to FibonacciHeap(includedSet);
                searchResult.setRoute(closest.getRoute());
                searchResult.deleteRoute(searchResult.getRoute().size()-1);
                searchResult.addRoute(true);
                //if (closest.getEdges().contains(new Edge(closest, searchResult, 5, true))) continue;
                boolean isContinue = false;
                Edge tmp = new Edge(closest, searchResult, 5, true);
                for (int j=0; j<closest.getEdges().size(); j++) {
                    if (closest.getEdges().elementAt(j).equals(tmp)) {
                        isContinue = true;
                        break;
                    }
                }
                if (isContinue) continue;
                closest.add(closest, searchResult, 5, true);//bug !
            }
            includedSet = FibonacciHeap.merge(includedSet, getFibHeapFrom(closest));
            
            closest = includedSet.min().getValue();
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append(closest.toString());
        sb.append('\n');
        sb.append((long)closest.getMinTime());
        refresh();
        return sb.toString();
    }
    
    public void refresh() {
        Set<String> keys = numberTable.keySet();
        for (String key : keys) {
            Vertex curr = numberTable.get(key);
            curr.setVisited(false);
            curr.setMinTime(-1);
            curr.setRoute(curr.getName());
            //need this?
            for (int i=0; i<curr.getEdges().size(); i++) {
                if (curr.getEdges().elementAt(i).getTransfer()) {
                    curr.getEdges().remove(i);
                }
            }
        }
    }
    
    public Vertex searchByNumber(String number) {
        return numberTable.get(number);
    }
    
    public Vector<String> searchByName(String name) {
        return nameTable.get(name);
    }
    
    public FibonacciHeap<Vertex> getFibHeapFrom(Vertex rhs) {
        FibonacciHeap<Vertex> result = new FibonacciHeap<>();
        
        Vector<Edge> rhsEdges = rhs.getEdges();
        
        int size = rhsEdges.size();
        
        for (int i=0; i<size; i++) {
            Edge next = rhsEdges.elementAt(i);
            Vertex nextV = next.getTo();
            
            if (!nextV.getVisited()) {
                if (nextV.getMinTime() == -1 || nextV.getMinTime() > next.getWeight() + rhs.getMinTime()) {
                    nextV.setRoute(rhs.getRoute());
                    if (next.getTransfer()) {
                        nextV.deleteRoute(nextV.getRoute().size()-1);
                        nextV.addRoute(true);
                    } else {
                        nextV.addRoute(false);
                    }
                    nextV.setMinTime(next.getWeight() + rhs.getMinTime());
                    result.enqueue(nextV, nextV.getMinTime());
                }
            }
        }
        return result;
    }
    
    public boolean isEnd(Vector<String> destinationStation, String number) {
        for (int i=0; i<destinationStation.size(); i++) {
            if (destinationStation.elementAt(i).equals(number)) {
                return true;
            }
        }
        return false;
    }
    
    private void nameCopy(Hashtable<String, Vector<String>> lhs, AVLTree<String, Vector<String>> rhs) {
        AVLNode<String, Vector<String>> head = rhs.getHead();
        
        recursiveNameCopy(lhs, head);
    }
    private void recursiveNameCopy(Hashtable<String, Vector<String>> lhs, AVLNode<String, Vector<String>> curr) {
        if (curr == null) return;
        
        lhs.put(curr.getKey(), curr.getValue());
        recursiveNameCopy(lhs, curr.getLeft());
        recursiveNameCopy(lhs, curr.getRight());
    }
    
    private void numberCopy(Hashtable<String, Vertex> lhs, AVLTree<String, Vertex> rhs) {
        AVLNode<String, Vertex> head = rhs.getHead();
        
        recursiveNumberCopy(lhs, head);
    }
    private void recursiveNumberCopy(Hashtable<String, Vertex> lhs, AVLNode<String, Vertex> curr) {
        if (curr == null) {
            return;
        }
        lhs.put(curr.getKey(), curr.getValue());
        recursiveNumberCopy(lhs, curr.getLeft());
        recursiveNumberCopy(lhs, curr.getRight());
    }
}