import java.util.Vector;

public class Vertex {
    private String number;
    private String name;
    private String line;
    private Vector<Edge> edges;
    private boolean isVisited = false;
    
    private double minTime;
    private Vector<String> route;
    
    public Vertex() {
        number = null;
        name = null;
        line = null;
        edges = new Vector<>();
        isVisited = false;
        minTime = -1;
    }
    
    public Vertex(String number, String name, String line) {
        this.number = number;
        this.name = name;
        this.line = line;
        edges = new Vector<>();
        isVisited = false;
        minTime = -1;
        route = new Vector<>();
        route.add(name);
    }
    
    public boolean getVisited() {
        return isVisited;
    }
    
    public void add(Vertex from, Vertex to, double weight, boolean isPermanent) {
        edges.add(new Edge(from, to, weight, isPermanent));
    }
    
    public void setVisited(boolean rhs) {
        isVisited = rhs;
    }
    
    public boolean equals(Vertex rhs) {
        return number.equals(rhs.getNumber());
    }
    
    public Vector<Edge> getEdges() {
        return edges;
    }
    
    public String getName() {
        return name;
    }
    
    public String getNumber() {
        return number;
    }
    
    public String getLine() {
        return line;
    }
    
    public double getMinTime() {
        return minTime;
    }
    public void setMinTime(double minTime) {
        this.minTime = minTime;
    }
    public Vector<String> getRoute() {
        return route;
    }
    
    public void setRoute(Vector<String> original) {
        route = new Vector<String>(original);
    }
    public void addRoute(boolean isTransfer) {
        if (isTransfer) {
            route.add("[" + name + "]");
        } else {
            route.add(name);
        }
    }
    public void deleteRoute(int index) {
        route.remove(index);
    }
    public void setRoute(Vertex rhs) {
        route = new Vector<String>(rhs.getRoute());
    }
    
    public void setRoute(String rhs) {
        this.route = new Vector<>();
        route.add(rhs);
    }
    
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i=0; i<route.size(); i++) {
            sb.append(route.elementAt(i));
            sb.append(" ");
        }
        sb.delete(sb.length()-1, sb.length());
        return sb.toString();
    }
    
    public boolean isLastTransfer() {
        return route.elementAt(route.size() - 1).charAt(0) == '[';
    }
}