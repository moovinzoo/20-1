import java.util.Vector;

public class Graph {
    private AVLTree<String, Vector<String>> nameTree;
    private AVLTree<String, Vertex> numberTree;
    
    public Graph() {
        nameTree = new AVLTree<>();
        numberTree = new AVLTree<>();
    }
    
    public void addStation(String number, String name, String line) {
        Vector<String> tmpString = new Vector<>();
        tmpString.add(number);
        
        AVLNode<String, Vector<String>> nameSearchResult;
        if ((nameSearchResult = nameTree.insert(name, tmpString)) != null) {
            //insert code to nameSearchResult;
            nameSearchResult.getValue().add(number);
        }
        
        Vertex tmpVertex = new Vertex(number, name, line);
        
        numberTree.insert(number, tmpVertex);
        
    }
    
    public void addInformation(String fromNumber, String toNumber, double time) {
        Vertex from = searchByNumber(fromNumber);
        Vertex to = searchByNumber(toNumber);
        
        from.add(from, to, time, false);
    }
    
    public String shortestPath(String fromName, String toName) {
        if (fromName.equals(toName)) {
            return fromName + '\n' + "0";
        }
        
        FibonacciHeap<Vertex> includedSet = new FibonacciHeap<>();
        
        Vector<String> startStation = searchByName(fromName);
        Vector<String> destinationStation = searchByName(toName);
        
        for (int i=0; i<startStation.size(); i++) {
            String stationNumber = startStation.elementAt(i);
            Vertex station = searchByNumber(stationNumber);
            
            station.setVisited(true);
            station.setMinTime(0);
            includedSet = FibonacciHeap.merge(includedSet, getFibHeapFrom(station));
        }
        
        Vertex closest = includedSet.min().getValue();
        
        //pathfinding
        while (!isEnd(destinationStation, closest.getNumber())) {
            double weight = includedSet.dequeueMin().getPriority();
            
            closest.setMinTime(weight);
            closest.setVisited(true);
            
            Vector<String> nameSearchResult = searchByName(closest.getName());

            for (int i=0; i<nameSearchResult.size(); i++) {
                Vertex searchResult = searchByNumber(nameSearchResult.elementAt(i));
                if (closest.equals(searchResult)) continue;
                if (searchResult.getVisited()) continue;
                //append searchResult to FibonacciHeap(includedSet);
                searchResult.setRoute(closest.getRoute());
                searchResult.deleteRoute(searchResult.getRoute().size()-1);
                searchResult.addRoute(true);
                closest.add(closest, searchResult, 5, false);
            }
            includedSet = FibonacciHeap.merge(includedSet, getFibHeapFrom(closest));
            
            closest = includedSet.min().getValue();
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append(closest.toString());
        sb.append('\n');
        sb.append((long)closest.getMinTime());
        refresh();
        return sb.toString();
    }
    
    public void refresh() {
        //for all vertex, set isVisited = false;
        AVLNode<String, Vertex> head = numberTree.getHead();
        
        recursiveRefresh(head);
    }
    public void recursiveRefresh(AVLNode<String, Vertex> curr) {
        if (curr == null) {
            return;
        }
        curr.getValue().setVisited(false);
        curr.getValue().setMinTime(-1);
        curr.getValue().setRoute(curr.getValue().getName());
        for (int i=0; i<curr.getValue().getEdges().size(); i++) {
            if (curr.getValue().getEdges().elementAt(i).getTransfer()) {
                curr.getValue().getEdges().remove(i);
            }
        }
        recursiveRefresh(curr.getLeft());
        recursiveRefresh(curr.getRight());
    }
    
    public Vertex searchByNumber(String number) {
        AVLNode<String, Vertex> searchResult;
        if ((searchResult = numberTree.explicitSearch(number)) == null) {
            return null;
        }
        return searchResult.getValue();
    }
    
    public Vector<String> searchByName(String name) {
        AVLNode<String, Vector<String>> searchResult;
        if ((searchResult = nameTree.explicitSearch(name)) == null) {
            return null;
        }
        return searchResult.getValue();
    }
    
    public Vertex searchByName(String name, String line) {
        AVLNode<String, Vector<String>> searchResult;
        if ((searchResult = nameTree.explicitSearch(name)) == null) {
            return null;
        }
        for (int i=0; i<searchResult.getValue().size(); i++) {
            Vertex curr = searchByNumber(searchResult.getValue().elementAt(i));
            if (curr.getLine().equals(line)) {
                return curr;
            }
        }
        return null;
    }
    
    public FibonacciHeap<Vertex> getFibHeapFrom(Vertex rhs) {
        FibonacciHeap<Vertex> result = new FibonacciHeap<>();
        
        Vector<Edge> rhsEdges = rhs.getEdges();
        
        for (int i=0; i<rhsEdges.size(); i++) {
            Edge next = rhsEdges.elementAt(i);
            Vertex nextV = next.getTo();

            if (!nextV.getVisited()) {
                if (!nextV.isLastTransfer()) {
                    nextV.setRoute(rhs.getRoute());
                    nextV.addRoute(false);
                }
                nextV.setMinTime(next.getWeight() + rhs.getMinTime());
                result.enqueue(nextV, nextV.getMinTime());
            }
        }
        return result;
    }
    
    public boolean isEnd(Vector<String> destinationStation, String number) {
        for (int i=0; i<destinationStation.size(); i++) {
            if (destinationStation.elementAt(i).equals(number)) {
                return true;
            }
        }
        return false;
    }
    
    public AVLTree<String, Vector<String>> getNameTree() {
        return nameTree;
    }
    public AVLTree<String, Vertex> getNumberTree() {
        return numberTree;
    }
}