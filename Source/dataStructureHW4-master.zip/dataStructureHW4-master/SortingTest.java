import java.io.*;
import java.util.*;

public class SortingTest {
    public static void main(String args[]) {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        try {
            boolean isRandom = false;   // 입력받은 배열이 난수인가 아닌가?
            int[] value;    // 입력 받을 숫자들의 배열
            String nums = br.readLine();    // 첫 줄을 입력 받음
            if (nums.charAt(0) == 'r') {
                // 난수일 경우
                isRandom = true;    // 난수임을 표시

                String[] nums_arg = nums.split(" ");

                int numsize = Integer.parseInt(nums_arg[1]);    // 총 갯수
                int rminimum = Integer.parseInt(nums_arg[2]);   // 최소값
                int rmaximum = Integer.parseInt(nums_arg[3]);   // 최대값

                Random rand = new Random(); // 난수 인스턴스를 생성한다.

                value = new int[numsize];   // 배열을 생성한다.
                for (int i = 0; i < value.length; i++)  // 각각의 배열에 난수를 생성하여 대입
                    value[i] = rand.nextInt(rmaximum - rminimum + 1) + rminimum;
            } else {
                // 난수가 아닐 경우
                int numsize = Integer.parseInt(nums);

                value = new int[numsize];   // 배열을 생성한다.
                for (int i = 0; i < value.length; i++)  // 한줄씩 입력받아 배열원소로 대입
                    value[i] = Integer.parseInt(br.readLine());
            }

            // 숫자 입력을 다 받았으므로 정렬 방법을 받아 그에 맞는 정렬을 수행한다.
            while (true) {
                int[] newvalue = (int[])value.clone();  // 원래 값의 보호를 위해 복사본을 생성한다.

                String command = br.readLine();

                long t = System.currentTimeMillis();
                switch (command.charAt(0)) {
                case 'B':   // Bubble Sort
                    newvalue = DoBubbleSort(newvalue);
                    break;
                case 'I':   // Insertion Sort
                    newvalue = DoInsertionSort(newvalue);
                    break;
                case 'H':   // Heap Sort
                    newvalue = DoHeapSort(newvalue);
                    break;
                case 'M':   // Merge Sort
                    newvalue = DoMergeSort(newvalue);
                    break;
                case 'Q':   // Quick Sort
                    newvalue = DoQuickSort(newvalue);
                    break;
                case 'R':   // Radix Sort
                    newvalue = DoRadixSort(newvalue);
                    break;
                case 'X':
                    return; // 프로그램을 종료한다.
                default:
                    throw new IOException("잘못된 정렬 방법을 입력했습니다.");
                }
                if (isRandom) {
                    // 난수일 경우 수행시간을 출력한다.
                    System.out.println((System.currentTimeMillis() - t) + " ms");
                } else {
                    // 난수가 아닐 경우 정렬된 결과값을 출력한다.
                    for (int i = 0; i < newvalue.length; i++) {
                        System.out.println(newvalue[i]);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("입력이 잘못되었습니다. 오류 : " + e.toString());
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    private static int[] DoBubbleSort(int[] value) {
        // value는 정렬안된 숫자들의 배열이며 value.length 는 배열의 크기가 된다.
        // 결과로 정렬된 배열은 리턴해 주어야 하며, 두가지 방법이 있으므로 잘 생각해서 사용할것.
        // 주어진 value 배열에서 안의 값만을 바꾸고 value를 다시 리턴하거나
        // 같은 크기의 새로운 배열을 만들어 그 배열을 리턴할 수도 있다.

        int numOfSwap;
        for (int i=0; i<value.length - 1; i++) {
            numOfSwap = 0;
            for (int j=0; j<value.length - 1 - i; j++) {
                if (value[j] > value[j+1]) {
                    //swap
                    swap(value, j, j+1);
                    //int temp = value[j];
                    //value[j] = value[j+1];
                    //value[j+1] = temp;

                    numOfSwap++;
                }
            }
            if (numOfSwap == 0) {
                break;
            }
        }
        return (value);
    }

    private static void swap(int[] value, int index1, int index2) {
        int temp = value[index1];
        value[index1] = value[index2];
        value[index2] = temp;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    private static int[] DoInsertionSort(int[] value) {

        for (int i=1; i<value.length; i++) {
            int j = i;
            int temp = value[j];

            //shifting
            for (; j>0 && value[j-1] > temp; j--) {
                value[j] = value[j-1];
            }
            value[j] = temp;
        }

        return (value);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    private static int[] DoHeapSort(int[] value) {

        for (int i=value.length/2; i>0; i--) {
            percolateDown(value, i, value.length);
        }

        for (int size = value.length - 1; size > 0; size--) {
            swap(value, 0, size);
            percolateDown(value, 1, size);
        }
        return (value);
    }

    //index starts at 1!
    private static void percolateDown(int[] value, int index, int size) {
        int targetIndex = index * 2;
        int rightIndex = index * 2 + 1;

        if (targetIndex <= size) {
            if (rightIndex <= size && value[targetIndex - 1] < value[rightIndex - 1]) {
                targetIndex = rightIndex;
            }

            if (value[index - 1] < value[targetIndex - 1]) {
                swap(value, index-1, targetIndex - 1);
                percolateDown(value, targetIndex, size);
            }
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    private static int[] DoMergeSort(int[] value) {

        return mergeSort(value, 0, value.length-1);

        //return (value);
    }

    private static int[] mergeSort(int[] value, int startIndex, int endIndex) {
        if (startIndex == endIndex) {   //when size 1
            return Arrays.copyOfRange(value, startIndex, endIndex+1);
        }

        int[] firstHalf;// = new int[(endIndex - startIndex + 2) / 2];
        int[] secondHalf;// = new int[(endIndex - startIndex + 1) / 2];

        firstHalf = mergeSort(value, startIndex, (endIndex + startIndex) / 2);
        secondHalf = mergeSort(value, (endIndex + startIndex ) / 2 + 1, endIndex);

        return merge(firstHalf, secondHalf);
        //return (value);
    }

    private static int[] merge(int[] lhs, int[] rhs) {
        int[] merged = new int[lhs.length + rhs.length];

        int mergeIndex = 0;
        int lhsIndex = 0;
        int rhsIndex = 0;

        while (lhsIndex < lhs.length && rhsIndex < rhs.length) {
            if (lhs[lhsIndex] <= rhs[rhsIndex]) {
                merged[mergeIndex] = lhs[lhsIndex];
                lhsIndex++;
            } else {
                merged[mergeIndex] = rhs[rhsIndex];
                rhsIndex++;
            }
            mergeIndex++;
        }

        while (lhsIndex < lhs.length) {
            merged[mergeIndex++] = lhs[lhsIndex++];
        }

        while (rhsIndex < rhs.length) {
            merged[mergeIndex++] = rhs[rhsIndex++];
        }

        return merged;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    private static int[] DoQuickSort(int[] value) {

        quickSort(value, 0, value.length-1);

        return (value);
    }

    private static void quickSort(int[] value, int startIndex, int endIndex) {
        if (startIndex < endIndex) {
            int pivot = partition(value, startIndex, endIndex);
            quickSort(value, startIndex, pivot - 1);
            quickSort(value, pivot + 1, endIndex);
        }
    }

    //partition at least 2 elements
    private static int partition(int[] value, int startIndex, int endIndex) {
        if (startIndex == endIndex - 1) {
            if (value[startIndex] > value[endIndex]) {
                swap(value, startIndex, endIndex);
            }
            return startIndex;
        }

        int pivot = pivot(value, startIndex, endIndex);
        int leftIndex = startIndex + 1;
        int rightIndex = endIndex;
        //copy from : http://www.algolist.net/Algorithms/Sorting/Quicksort
        while (leftIndex <= rightIndex) {
            while (value[leftIndex] < pivot) {  //피벗보다 크거나 같은 것을 찾는다
                leftIndex++;
            }

            while (value[rightIndex] > pivot) { //피벗보다 작거나 같은 것을 찾는다
                rightIndex--;
            }
            if (leftIndex <= rightIndex) {
                swap(value, leftIndex, rightIndex);
                leftIndex++;
                rightIndex--;
            }
        }
        //copy end
        swap(value, rightIndex, startIndex);

        return rightIndex;
    }

    private static int pivot(int[] value, int startIndex, int endIndex) {
        int pivotIndex = pivotIndex(value, startIndex, endIndex);

        swap(value, startIndex, pivotIndex);
        return value[startIndex];
    }

    private static int pivotIndex(int[] value, int startIndex, int endIndex) {
        //return index of middle of value[startIndex], value[midIndex], value[endIndex]
        int midIndex = (startIndex + endIndex) / 2;

        if (value[startIndex] > value[endIndex]) {
            if (value[startIndex] > value[midIndex]) {
                if (value[endIndex] > value[midIndex]) {
                    return endIndex;
                } else {
                    return midIndex;
                }
            } else {
                return startIndex;
            }
        } else {
            if (value[startIndex] > value[midIndex]) {
                return startIndex;
            } else {
                if (value[midIndex] > value[endIndex]) {
                    return endIndex;
                } else {
                    return midIndex;
                }
            }
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    private static int[] DoRadixSort(int[] value) {
        
        int max = value[0];
        int min = value[0];
        for (int i=1; i<value.length; i++) {
            if (max < value[i]) {
                max = value[i];
            } else if (min > value[i]) {
                min = value[i];
            }
        }

        max = (max<0)? -max : max;
        min = (min<0)? -min : min;
        
        int maxDigit = (int)Math.log10((double)max)+1 > (int)Math.log10((double)(min))+1 ?
                (int)Math.log10((double)max)+1 : (int)Math.log10((double)(min))+1;

        Queue<Integer>[] buckets = new Queue[19];//from -9 to 9//new LinkedList[19];

        //for every digit
        for (int i=0; i<maxDigit; i++) {
            //initialize
            for (int j=0; j<buckets.length; j++) {
                buckets[j] = new LinkedList<Integer>();
            }

            int mask = (int)Math.pow(10.0, (double)i);

            //for every number in value[]
            for (int k=0; k<value.length; k++) {
                buckets[value[k] / mask % 10 + 9].add(value[k]);
            }

            int j = 0;
            for (int k=0; k<buckets.length; k++) {
                while (!buckets[k].isEmpty()) {
                    value[j++] = buckets[k].remove();
                }
            }
        }
        return (value);
    }
}