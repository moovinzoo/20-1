//
//  Person.cpp
//  PhoneBook
//
//  Created by lightb0x on 2016. 4. 4..
//  Copyright © 2016년 lightb0x. All rights reserved.
//

#include "Person.hpp"
#include <cmath>
#include <iostream>
#include <string>

using namespace std;

Person::Person(const string &firstName, const string &lastName, const string& phoneNum) {
    this->firstName = firstName;
    this->lastName = lastName;
    this->phoneNumberInfo = toPhoneNumberInfo(phoneNum);
}

Person::Person(const Person & rhs){   //copy constructor
    this->firstName = rhs.firstName;
    this->lastName = rhs.lastName;
    this->phoneNumberInfo = rhs.phoneNumberInfo;
}

Person::~Person() {
    ;
}

void Person::setFirstName(const string &firstName) {
    this->firstName = firstName;
}

void Person::setLastName(const string &lastName) {
    this->lastName = lastName;
}

void Person::setPhoneNumber(const string &phoneNum) {
    this->phoneNumberInfo = toPhoneNumberInfo(phoneNum);
}

const string& Person::getFirstName() const {
    return this->firstName;
}

const string& Person::getLastName() const {
    return this->lastName;
}

long Person::getPhoneNumberInfo() const {
    return this->phoneNumberInfo;
}

long Person::toPhoneNumberInfo(const string & phoneNum) {//static
    
    if (phoneNum.find("-") == string::npos) {//01024592062 case
        return -1l;
    }
    
    if (phoneNum.find_first_of("-") == phoneNum.find_last_of("-")) {//one '-' case
        return -1l;
    }
    
    if (phoneNum.length() < 11 || phoneNum.length() > 13) {
        return -1l;
    }
    
    //010-2459-2062 case
    int firstIndex = (int)phoneNum.find_first_of("-");   //3 this case
    int lastIndex = (int)phoneNum.find_last_of("-");     //8 this case
    
    int firstLength = firstIndex;                           //3 this case
    int middleLength = lastIndex - firstIndex - 1;          //4 this case
    int lastLength = (int)phoneNum.length() - lastIndex - 1;//4 this case
    
    long phoneNumberInfo = (long)firstLength;   //3
    
    phoneNumberInfo *= 10;                      //30
    phoneNumberInfo += middleLength;            //34
    
    phoneNumberInfo *= 10;                      //340
    phoneNumberInfo += lastLength;              //344
    
    phoneNumberInfo *= (long)pow(10.0, (double)firstLength);    //344000
    phoneNumberInfo += stoi(phoneNum.substr(0, firstLength));   //344010
    
    phoneNumberInfo *= (long)pow(10.0, (double)middleLength);   //3440100000
    phoneNumberInfo += stoi(phoneNum.substr(firstLength+1, middleLength));  //3440102459
    
    phoneNumberInfo *= (long)pow(10.0, (double)lastLength);     //34401024590000
    phoneNumberInfo += stoi(phoneNum.substr(firstLength + middleLength + 2, lastLength));//34401024592062
    
    return phoneNumberInfo;
}

string Person::getPhoneNumber() const {
    
    long phoneNumberInfo = this->phoneNumberInfo;
    
    int lengthInfo = this->getLengthInfo();
    
    
    int frontLength = lengthInfo / 100;         //3
    int middleLength = lengthInfo % 100 / 10;   //4
    int lastLength = lengthInfo % 10;           //4
    
    long firstMask = (long)pow(10.0, (double)(frontLength + middleLength + lastLength));
    long secondMask = (long)pow(10.0, (double)(middleLength + lastLength));
    long thirdMask = (long)pow(10.0, (double)(lastLength));
    
    string result = "";
    
    string firstNumber = to_string((int)(phoneNumberInfo % firstMask / secondMask));  //10
    string secondNumber = to_string((int)(phoneNumberInfo % secondMask / thirdMask)); //2459
    string thirdNumber = to_string((int)(phoneNumberInfo % thirdMask));               //2062
    
    //0 handling;
    for (int i=0; i<frontLength - firstNumber.length(); i++) {//for 'number of 0' times
        result += "0";
    }
    result += firstNumber;
    
    result += "-";
    
    for (int i=0; i<middleLength - secondNumber.length(); i++) {
        result += "0";
    }
    result += secondNumber;
    
    result += "-";
    
    for (int i=0; i<lastLength - thirdNumber.length(); i++) {
        result += "0";
    }
    result += thirdNumber;
    
    return result;
}

void Person::print() const {
    cout << this->firstName << " " << this->lastName << "_" << this->getPhoneNumber() << endl;
}

int Person::getLengthInfo() const {
    
    long mask = (long)pow(10.0, 18.0);  //1,000,000,000,000,000,000
                                        //9,223,372,036,854,775,807 == long.MAX_VALUE
    while (phoneNumberInfo / mask == 0) {
        mask = mask / 10;
    }
    mask = mask / 100;
    
    return (int)(phoneNumberInfo / mask);
}

bool Person::isError() const {
    if (this->getPhoneNumberInfo() == -1l) {
        return true;
    }
    return false;
}