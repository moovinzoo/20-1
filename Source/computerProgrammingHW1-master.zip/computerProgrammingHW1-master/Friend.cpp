//
//  Friend.cpp
//  PhoneBook
//
//  Created by lightb0x on 2016. 4. 4..
//  Copyright © 2016년 lightb0x. All rights reserved.
//

#include "Friend.hpp"
#include <string>
#include <iostream>

using namespace std;

Friend::Friend(const string &firstName, const string &lastName, const string& phoneNum, const int age) : Person(firstName, lastName, phoneNum) {
    this->age = age;
}

Friend::Friend(Friend & rhs) : Person(rhs) {   //copy constructor
    this->age = rhs.age;
}

void Friend::setAge(const int age) {
    if (age > 0) {
        this->age = age;
    } else {
        this->age = -1;
    }
}

int Friend::getAge() const {
    return this->age;
}

void Friend::print() const {
    cout << this->getFirstName() << " " << this->getLastName() << "_" << this->getPhoneNumber() << "_" << this->age << endl;
}

bool Friend::isError() const {
    if (this->Person::isError()) {
        return true;
    }
    if (this->getAge() < 0) {
        return true;
    }
    return false;
}