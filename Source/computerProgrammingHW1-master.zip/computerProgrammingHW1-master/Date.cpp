//
//  Date.cpp
//  PhoneBook
//
//  Created by lightb0x on 2016. 4. 12..
//  Copyright © 2016년 lightb0x. All rights reserved.
//

#include "Date.hpp"

Date::Date(const string & rhs) {
    if (Date::isFormatted(rhs)) {
        datef = rhs;
    } else {
        datef = ERROR_MSG;
    }
}

Date::Date(int year, int month, int day) {
    if (year < 0) {
        datef = ERROR_MSG;
        return;
    }
    if (month < 0 || month > 12) {
        datef = ERROR_MSG;
        return;
    }
    if (day < 0 || day > dayOfMonth(year, month)) {
        datef = ERROR_MSG;
        return;
    }
    
    this->setDatef(year, month, day);
}

Date::Date(Date & rhs) {   //copy constructor
    this->datef = rhs.datef;
}

Date::Date(Date && rhs) {  //move semantic
    this->datef = rhs.datef;
}

Date::~Date() {
    ;
}

Date & Date::operator=(const Date & rhs) {
    this->datef = rhs.datef;
    return *this;
}

Date & Date::operator=(const Date && rhs) {
    this->datef = rhs.datef;
    return *this;
}

bool Date::operator==(const Date & rhs) const {
    if (this->getDay() == rhs.getDay() && this->getMonth() == rhs.getMonth()) {
        return true;
    }
    return false;
}

Date & Date::operator++(int) { //post addition
    int nowDay = this->getDay();
    int nowMonth = this->getMonth();
    int nowYear = this->getYear();
    
    nowDay++;
    if (nowDay > dayOfMonth(nowYear, nowMonth)) {
        nowDay = 1;
        nowMonth++;
        if (nowMonth > 12) {
            nowMonth = 1;
            nowYear++;
            if (nowYear == 100) {
                nowYear = 0;
            }
        }
    }
    
    this->setDatef(nowYear, nowMonth, nowDay);
    return *this;
}


int Date::getYear() const {
    if (datef == ERROR_MSG) return -1;
    return stoi(this->datef.substr(YEAR_INDEX, YEAR_LENGTH));
}

int Date::getMonth() const {
    if (datef == ERROR_MSG) return -1;
    return stoi(this->datef.substr(MONTH_INDEX, MONTH_LENGTH));
}

int Date::getDay() const {
    if (datef == ERROR_MSG) return -1;
    return stoi(this->datef.substr(DAY_INDEX, DAY_LENGTH));
}

string Date::getDatef() const {
    return this->datef;
}

void Date::setDatef(int year, int month, int day) {
    this->datef = toDatef(year, month, day);
}

string Date::toDatef(int year, int month, int day) const {
    string dateFormatted = "";
    
    if (year == 0) {
        dateFormatted += "00";
    } else if (year < 10) {
        dateFormatted += "0";
        dateFormatted += to_string(year);
    } else {
        dateFormatted += to_string(year);
    }
    
    if (month == 0) {
        dateFormatted += "00";
    } else if (month < 10) {
        dateFormatted += "0";
        dateFormatted += to_string(month);
    } else {
        dateFormatted += to_string(month);
    }
    
    if (day == 0) {
        dateFormatted += "00";
    } else if (day < 10) {
        dateFormatted += "0";
        dateFormatted += to_string(day);
    } else {
        dateFormatted += to_string(day);
    }
    
    return dateFormatted;
}

int Date::dDay(const Date & specialDate) { // static
    
    time_t t = time(0);   // get time of runtime
    struct tm * now = localtime( & t );
    int nowYear = (now->tm_year + 1900)%100;
    int nowMonth = (now->tm_mon + 1);
    int nowDay = (now->tm_mday);
    
    int specialMonth = specialDate.getMonth();
    int specialDay = specialDate.getDay();
    
    int result = 0;
    
    //dDay calculation
    Date nowDate(nowYear, nowMonth, nowDay);
    while (!nowDate.isSameDay(specialMonth, specialDay)) {
        nowDate++;
        result++;
    }
    
    return result;
}

//error handling : return -1 if year is negative or month not in 1~12
int Date::dayOfMonth(int year, int month) {//static
    if (year < 0) {
        return -1;
    }
    
    switch (month) {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
            return 31;
            break;
            
        case 4:
        case 6:
        case 9:
        case 11:
            return 30;
            break;
            
        case 2:
            if (isLeapYear(year)) return 29;
            return 28;
            break;
            
        default:
            return -1;
            break;
    }
}

//error handling : return false when year is negative
bool Date::isLeapYear(int year) {//static
    if (year < 0) {
        return false;
    }
    
    if (year % 4 == 0) {
        if (year % 100 == 0) {
            if (year % 400 == 0) {
                return true;
            }
            return false;
        }
        return true;
    }
    return false;
}

//return true only if "month and day" is same.
bool Date::isSameDay(int month, int day) const {
    if (this->getDay() == day && this->getMonth() == month) {
        return true;
    }
    return false;
}

bool Date::isFormatted(const string & date) {//static
    
    //format of birthday is :
    //YYMMDD
    //ex)160404
    
    if (date.length() != YEAR_LENGTH + MONTH_LENGTH + DAY_LENGTH) {
        return false;
    }
    
    for (int i = 0; i<date.length(); i++) {
        if (!isdigit(date[i])) {
            return false;
        }
    }
    int year = stoi(date.substr(YEAR_INDEX, YEAR_LENGTH));
    int month = stoi(date.substr(MONTH_INDEX, MONTH_LENGTH));
    int day = stoi(date.substr(DAY_INDEX, DAY_LENGTH));
    
    if (year < 0) {
        return false;
    }
    if (month < 0 || month > 12) {
        return false;
    }
    if (day < 0 || day > dayOfMonth(year, month)) {
        return false;
    }
    return true;
}

bool Date::isError() const {
    if (datef == ERROR_MSG) return true;
    return false;
}