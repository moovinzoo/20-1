//
//  Person.hpp
//  PhoneBook
//
//  Created by lightb0x on 2016. 4. 4..
//  Copyright © 2016년 lightb0x. All rights reserved.
//

#ifndef Person_hpp
#define Person_hpp

#include <string>

using namespace std;

class Person {
public:
    Person(const string &firstName, const string &lastName, const string& phoneNum);
    
    Person(const Person & rhs);   //copy constructor
    
    virtual ~Person();
    
    void setFirstName(const string &firstName);
    void setLastName(const string &lastName);
    void setPhoneNumber(const string &phoneNum);
    
    const string& getFirstName() const;
    const string& getLastName() const;
    string getPhoneNumber() const;
    int getLengthInfo() const;//ex)344
    
    long getPhoneNumberInfo() const;
    
    virtual bool isError() const;
    
    virtual void print() const;
    
    
private:
    static long toPhoneNumberInfo(const string & phoneNum);
    
    string firstName;
    string lastName;
    long phoneNumberInfo;//ex)34401024592062//length + phone number
};

#endif /* Person_hpp */
