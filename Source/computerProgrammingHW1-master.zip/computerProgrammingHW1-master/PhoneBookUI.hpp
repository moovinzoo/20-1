//
//  PhoneBookUI.hpp
//  PhoneBook
//
//  Created by lightb0x on 2016. 4. 12..
//  Copyright © 2016년 lightb0x. All rights reserved.
//

#ifndef PhoneBookUI_hpp
#define PhoneBookUI_hpp

#include "PhoneBookDB.hpp"

class PhoneBookUI {
public:
    int run(PhoneBookDB pbDB);
    void printMenu() const;
    void printType() const;
    void printPrompt() const;
    void printErrorMsg() const;
    
};

#endif /* PhoneBookUI_hpp */
