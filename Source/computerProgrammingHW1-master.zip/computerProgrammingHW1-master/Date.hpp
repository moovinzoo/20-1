//
//  Date.hpp
//  PhoneBook
//
//  Created by lightb0x on 2016. 4. 12..
//  Copyright © 2016년 lightb0x. All rights reserved.
//

#ifndef Date_hpp
#define Date_hpp

#include <string>
#include <ctime>

#define ERROR_MSG "INAPPROPRIATE INPUT, FORMAT YYMMDD"

#define YEAR_INDEX 0
#define YEAR_LENGTH 2

#define MONTH_INDEX 2
#define MONTH_LENGTH 2

#define DAY_INDEX 4
#define DAY_LENGTH 2

using namespace std;

class Date {
public:
    Date(const string & rhs);
    Date(const int year, const int month, const int day);
    
    Date(Date & rhs);   //copy constructor
    Date(Date && rhs);  //move semantic
    
    ~Date();
    
    Date & operator=(const Date & rhs);   //copy assignment
    Date & operator=(const Date && rhs);  //move assignment
    
    bool operator==(const Date & rhs) const;    //isSame
    
    Date & operator++(int); //post addition
    
    int getYear() const;
    int getMonth() const;
    int getDay() const;
    string getDatef() const;
    
    void setDatef(int year, int month, int day);
    string toDatef(int year, int month, int day) const;
    
    static int dDay(const Date & till);
    
    static int dayOfMonth(int year, int month);
    static bool isLeapYear(int year);
    
    bool isSameDay(int month, int day) const;
    static bool isFormatted(const string & date);
    
    bool isError() const;
    
private:
    string datef;
};

#endif /* Date_hpp */
