//
//  Friend.hpp
//  PhoneBook
//
//  Created by lightb0x on 2016. 4. 4..
//  Copyright © 2016년 lightb0x. All rights reserved.
//

#ifndef Friend_hpp
#define Friend_hpp

#include "Person.hpp"

class Friend : public Person { //age
public:
    using Person::Person;
    
    Friend(const string &firstName, const string &lastName, const string& phoneNum, const int age);
    
    Friend(Friend & rhs);   //copy constructor
    
    void setAge(const int age);
    int getAge() const;
    
    virtual bool isError() const;
    
    virtual void print() const;
    
private:
    int age;
    
};

#endif /* Friend_hpp */
