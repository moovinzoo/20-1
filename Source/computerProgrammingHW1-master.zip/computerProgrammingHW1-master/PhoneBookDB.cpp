//
//  PhoneBookDB.cpp
//  PhoneBook
//
//  Created by lightb0x on 2016. 4. 12..
//  Copyright © 2016년 lightb0x. All rights reserved.
//

#include "PhoneBookDB.hpp"

#include <string>
#include <iostream>

using namespace std;

PhoneBookDB::PhoneBookDB() {
    ;
}

PhoneBookDB::~PhoneBookDB() {
    ;
}


void PhoneBookDB::add(Person * input) {
    if (input->isError()) {
        cout << "INVALID INPUT FORMAT" << endl;
        return;
    }

    phoneBook.push_back(input);
    cout << "Successfully added new person." << endl;
}

void PhoneBookDB::removeAt(int index) { // index start at 0
    
    if (index >= phoneBook.size() || index < 0) {
        cout << "Person does not exist!" << endl;
        return;
    }
    
    delete phoneBook.at(index);
    
    vector<Person *>::iterator it = phoneBook.begin();
    it += index;
    phoneBook.erase(it);
    cout << "A person is successfully deleted from the Phone Book!" << endl;
}

void PhoneBookDB::printAll() const {
    for (int i=0; i<phoneBook.size(); i++) {
        cout << to_string(i+1) << ". ";
        phoneBook[i]->print();
    }
}
