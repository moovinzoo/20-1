//
//  PhoneBookUI.cpp
//  PhoneBook
//
//  Created by lightb0x on 2016. 4. 12..
//  Copyright © 2016년 lightb0x. All rights reserved.
//

#include "PhoneBookUI.hpp"
#include <iostream>
#include <string>

using namespace std;

int PhoneBookUI::run(PhoneBookDB pbDB) {
    string menuSelect = "";
    
    while (true) {
        printMenu();
        printPrompt();
        fflush(stdin);
        cin >> menuSelect;
        
        if (menuSelect == "quit") {
            cout << "Bye." << endl;
            break;
        }
        
        if (!(menuSelect.length() == 1 && isdigit(menuSelect[0]))) {//error handling in case of string not invertible to integer
            printErrorMsg();
            continue;
        }
        switch (stoi(menuSelect)) {
            case 1: {//add
                int typeSelect;
                printType();
                printPrompt();
                fflush(stdin);
                cin >> typeSelect;
                
                string firstName;
                string lastName;
                string phoneNumber;
                
                switch (typeSelect) {
                    case 1: {//Person
                        cout << "Name: ";
                        cin >> firstName >> lastName;
                        cout << "Phone_number: ";
                        cin >> phoneNumber;
                        Person * newPerson = new Person(firstName, lastName, phoneNumber);
                        pbDB.add(newPerson);
                        break;
                    }
                    case 2: {//Work
                        string team;
                        cout << "Name: ";
                        cin >> firstName >> lastName;
                        cout << "Phone_number: ";
                        cin >> phoneNumber;
                        cout << "team: ";
                        cin >> team;
                        Work * newWorkMember = new Work(firstName, lastName, phoneNumber, team);
                        pbDB.add(newWorkMember);
                        break;
                    }
                    case 3: {//Family
                        string birthday;
                        cout << "Name: ";
                        cin >> firstName >> lastName;
                        cout << "Phone_number: ";
                        cin >> phoneNumber;
                        cout << "Birthday: ";
                        cin >> birthday;
                        Family * newFamilyMember = new Family(firstName, lastName, phoneNumber, birthday);
                        pbDB.add(newFamilyMember);
                        break;
                    }
                    case 4: {//Friend
                        int age;
                        cout << "Name: ";
                        cin >> firstName >> lastName;
                        cout << "Phone_number: ";
                        cin >> phoneNumber;
                        cout << "age: ";
                        cin >> age;
                        Friend * newFriend = new Friend(firstName, lastName, phoneNumber, age);
                        pbDB.add(newFriend);
                        break;
                    }
                    default:
                        printErrorMsg();
                        break;
                }
                
                break;
            }
            case 2: {//remove
                int removeIndex;
                cout << "Enter Index of person: ";
                cin >> removeIndex;
                pbDB.removeAt(removeIndex-1);//invert user-index(start at 1) to C-index (start at 0) 
                break;
            }
            case 3: {//print
                cout << "Phone Book Print" << endl;
                pbDB.printAll();
                break;
            }
            default:
                printErrorMsg();
                break;
        }
    }
    
    return 0;
}

void PhoneBookUI::printPrompt() const {
    cout << "CP-2015-12139>";
}

void PhoneBookUI::printMenu() const {
    printPrompt(); cout << endl;
    cout << "Phone Book" << endl;
    cout << "1. Add person" << endl;
    cout << "2. Remove person" << endl;
    cout << "3. Print phone book" << endl;
}

void PhoneBookUI::printType() const {
    cout << "Select Type" << endl;
    cout << "1. Person" << endl;
    cout << "2. Work" << endl;
    cout << "3. Family" << endl;
    cout << "4. Friend" << endl;
}

void PhoneBookUI::printErrorMsg() const {
    cout << "INPUT ERROR" << endl;
    cout << "input appropriate index" << endl;
}