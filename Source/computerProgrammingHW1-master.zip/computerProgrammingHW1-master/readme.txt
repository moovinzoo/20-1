please visit

https://github.com/lightb0x/computerProgrammingHW1.git

for development history or in case of data loss.


*submitted program is 12nd commit version.




to run this program, enter
“g++ -std=c++11 *.cpp *.hpp”	//this program is based on C++11 standard.
into linux console.


enter “quit” to end process.

date format is YYMMDD
phone number format is [n digit]-[n digit]-[n digit] total length of from 11 to 13 including dash.