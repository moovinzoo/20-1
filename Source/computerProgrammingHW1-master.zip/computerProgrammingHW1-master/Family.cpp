//
//  Family.cpp
//  PhoneBook
//
//  Created by lightb0x on 2016. 4. 4..
//  Copyright © 2016년 lightb0x. All rights reserved.
//

#include "Family.hpp"
#include <iostream>
#include <string>

using namespace std;

Family::Family(const string & firstName, const string & lastName, const string & phoneNumber, const string & birthday) : Person(firstName, lastName, phoneNumber) {
    this->birthday = new Date(birthday);
}

Family::Family(Family & rhs) : Person(rhs) {   //copy constructor
    delete this->birthday;
    this->birthday = rhs.birthday;
}

Family::~Family() {
    delete birthday;
}

//erorr handling : return -1 if not born yet
int Family::dDay() const {           //calculate date difference between birthday and current day
    return Date::dDay(*birthday);
}


//error handing : if input string is not in format, do nothing.
void Family::setBirthday(const string & birthday) {
    delete this->birthday;
    this->birthday = new Date(birthday);
}

string Family::getBirthday() const {
    return this->birthday->getDatef();
}

void Family::print() const {
    cout << this->getFirstName() << " " << this->getLastName() << "_" << this->getPhoneNumber() << "_" << this->getBirthday() << "_" << this->dDay() << endl;
}

bool Family::isError() const {
    if (this->Person::isError()) {
        return true;
    }
    if (this->birthday->Date::isError()) {
        return true;
    }
    return false;
}