//
//  main.cpp
//  PhoneBook
//
//  Created by lightb0x on 2016. 4. 4..
//  Copyright © 2016년 lightb0x. All rights reserved.
//

#include "PhoneBookUI.hpp"
#include "PhoneBookDB.hpp"

int main() {
    PhoneBookDB pbDB;
    PhoneBookUI pbUI;
    
    pbUI.run(pbDB);

    return 0;
}