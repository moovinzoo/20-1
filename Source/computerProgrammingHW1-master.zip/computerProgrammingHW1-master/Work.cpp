//
//  Work.cpp
//  PhoneBook
//
//  Created by lightb0x on 2016. 4. 4..
//  Copyright © 2016년 lightb0x. All rights reserved.
//

#include "Work.hpp"
#include "Person.hpp"
#include <iostream>
#include <string>

using namespace std;

Work::Work(const string & firstName, const string & lastName, const string & phoneNumber, const string & team) : Person(firstName, lastName, phoneNumber) {
    this->team = team;
}

Work::Work(Work & rhs) : Person(rhs) {  //copy constructor
    this->team = rhs.team;
}


void Work::setTeam(const string & team) {
    this->team = team;
}

string Work::getTeam() const {
    return this->team;
}

void Work::print() const {
    cout << this->getFirstName() << " " << this->getLastName() << "_" << this->getPhoneNumber() << "_" << this->team << endl;
}

bool Work::isError() const {
    if (this->Person::isError()) {
        return true;
    }
    
    return false;
}