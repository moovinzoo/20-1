//
//  Work.hpp
//  PhoneBook
//
//  Created by lightb0x on 2016. 4. 4..
//  Copyright © 2016년 lightb0x. All rights reserved.
//

#ifndef Work_hpp
#define Work_hpp

#include "Person.hpp"

class Work : public Person { // team
public:
    using Person::Person;
    
    Work(const string & firstName, const string & lastName, const string & phoneNumber, const string & team);
    
    Work(Work & rhs);   //copy constructor
    
    void setTeam(const string & team);
    string getTeam() const;
    
    virtual bool isError() const;
    
    virtual void print() const;
    
private:
    string team;
};

#endif /* Work_hpp */
