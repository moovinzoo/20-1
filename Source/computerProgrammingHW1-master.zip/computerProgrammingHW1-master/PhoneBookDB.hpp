//
//  PhoneBookDB.hpp
//  PhoneBook
//
//  Created by lightb0x on 2016. 4. 12..
//  Copyright © 2016년 lightb0x. All rights reserved.
//

#ifndef PhoneBookDB_hpp
#define PhoneBookDB_hpp

#include <vector>
#include "Person.hpp"
#include "Work.hpp"
#include "Friend.hpp"
#include "Family.hpp"
#include <iostream>

using namespace std;

class PhoneBookDB {
public:
    PhoneBookDB();
    ~PhoneBookDB();
    
    void add(Person * input);
    void removeAt(int index);
    void printAll() const;
    
private:
    vector<Person *> phoneBook;
};

#endif /* PhoneBookDB_hpp */
