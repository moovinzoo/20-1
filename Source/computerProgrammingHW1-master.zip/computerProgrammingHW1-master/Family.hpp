//
//  Family.hpp
//  PhoneBook
//
//  Created by lightb0x on 2016. 4. 4..
//  Copyright © 2016년 lightb0x. All rights reserved.
//

#ifndef Family_hpp
#define Family_hpp

#include "Person.hpp"
#include "Date.hpp"

class Family : public Person { // birthday!
public:
    using Person::Person;
    
    Family(const string & firstName, const string & lastName, const string & phoneNumber, const string & birthday);
    
    Family(Family & rhs);   //copy constructor
    
    ~Family();
    
    int dDay() const;           //calculate date difference between birthday and current day
    
    void setBirthday(const string & birthday);
    string getBirthday() const;
    
    virtual bool isError() const;
    
    virtual void print() const;
    
private:
    Date * birthday;
};

#endif /* Family_hpp */
