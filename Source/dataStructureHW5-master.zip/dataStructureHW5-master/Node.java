public class Node {
    private Key key;
    private Node prev;
    private Node next;
    
    public Node (Key key) {
        this.key = new Key(key);
        prev = null;
        next = null;
    }
    
    public Node(Key key, Node next) {
        this.key = new Key(key);
        this.prev = null;
        this.next = next;
    }
    
    public void connect(Node rhs) {
        this.next = rhs;
        rhs.prev = this;
    }
    
    public Node getPrev() {
        return this.prev;
    }
    public Node getNext() {
        return this.next;
    }
    
    public Key getKey() {
        return this.key;
    }
    
    public void setPrev(Node newNode) {
        this.prev = newNode;
    }
    public void setNext(Node newNode) {
        this.next = newNode;
    }
    
    @Override
    public String toString() {
        return "(" + key.getStringNumber() + ", " + key.getStartIndex() + ")";
    }
    
    public boolean equals(Node rhs) {
        if (rhs == null) return false;
        
        return key.equals(rhs.key);
    }
    
    public boolean equals(Node rhs, int shift) {
        if (rhs == null) return false;
        
        return key.equals(rhs.key, shift);
    }
}