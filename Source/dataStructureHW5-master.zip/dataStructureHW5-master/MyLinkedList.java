public class MyLinkedList {
    private Node dummyHead;
    private Node dummyTail;
    private int length;
    
    public MyLinkedList() {
        dummyHead = new Node(new Key(0, 0));
        dummyTail = new Node(new Key(0, 0));
        dummyHead.connect(dummyTail);
        length = 0;
    }
    
    public MyLinkedList(MyLinkedList rhs) {
        if (rhs == null) {
            return;
        }
        if (rhs.getLength() < 1) {
            return;
        }
        dummyHead = new Node(new Key(0, 0));
        dummyTail = new Node(new Key(0, 0));
        dummyHead.connect(dummyTail);
        length = 0;
        
        Node cursor = rhs.getItem(0);
        
        for (int i=0; i<rhs.getLength(); i++) {
            this.insert(cursor.getKey());
            cursor = cursor.getNext();
        }
    }

    public Node getItem(int index) {
        if (length < index + 1) {
            return null;
        }
        Node cursor = dummyHead.getNext();
        
        for (int i=0; i<index; i++) {
            cursor = cursor.getNext();
        }
        return cursor;
    }
    
    public void insert(Key key) {
        Node newNode = new Node(key);
        dummyTail.getPrev().connect(newNode);
        newNode.connect(dummyTail);
        length++;
    }
    
    //when index == 0, delete first node.
    public Node delete(int index) {
        if (length < index + 1) {
            return null;
        }
        Node targetPrev = dummyHead;
        
        for (int i=0; i<index; i++) {
            targetPrev = targetPrev.getNext();
        }
        
        Node target = targetPrev.getNext();
        
        targetPrev.connect(target.getNext());
        
        length--;
        return target;
    }
    
    public Node search(Key key) {
        if (length < 1) {
            return null;
        }
        Node cursor = getItem(0);
        
        while (cursor != dummyTail) {
            if (cursor.getKey().equals(key)) {
            //if (cursor.getStringNumber() == stringNumber && cursor.getStartIndex() == startIndex) {
                return cursor;
            }
        }
        return null;
    }
    
    public int getLength() {
        return this.length;
    }
    
    @Override
    public String toString() {
        if (length == 0) {
            return null;
        }
        Node cursor = dummyHead.getNext();
        
        StringBuilder sb = new StringBuilder();
        for (int i=0; i<length; i++) {
            //append COORD!
            sb.append(cursor.toString());
            sb.append(" ");
            cursor = cursor.getNext();
        }
        sb.delete(sb.length() - 1, sb.length());
        return sb.toString();
    }
    
    public boolean equals(MyLinkedList rhs) {
        if (rhs == null) return false;
        if (length != rhs.length) {
            return false;
        }
        
        Node cursor = dummyHead.getNext();
        Node cursorRhs = rhs.getItem(0);
        
        for (int i=0; i<length; i++) {
            if (!cursor.equals(cursorRhs)) {
                return false;
            }
        }
        return true;
    }
    /*
    public boolean equals(MyLinkedList rhs, int shift) {
        if (rhs == null) return false;
        if (length != rhs.length) {
            return false;
        }
        
        Node cursor = dummyHead.getNext();
        Node cursorRhs = rhs.getItem(0);
        
        for (int i=0; i<length; i++) {
            if (!cursor.equals(cursorRhs, shift)) {
                return false;
            }
        }
        return true;
    }
    */
    public MyLinkedList and(MyLinkedList rhs, int shift) {
        if (rhs == null) return null;
        if (rhs.getLength() < 1 || length < 1) return null;
        
        MyLinkedList result = new MyLinkedList();
        
        Node rhsCursor = rhs.getItem(0);
        Node cursor = dummyHead.getNext();
        
        while (cursor != dummyTail) {
            rhsCursor = rhs.getItem(0);
            for (int i=0; i<rhs.getLength(); i++) {
                if (rhsCursor.equals(cursor, shift)) {
                    result.insert(cursor.getKey());
                    //result.insert(cursor.getStringNumber(), cursor.getStartIndex());
                    break;
                }
                rhsCursor = rhsCursor.getNext();
            }
            cursor = cursor.getNext();
        }
        return result;
    }
}