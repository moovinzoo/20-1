public class MyHashTable {
    private AVLTree[] hashTable;
    private static final int LENGTH = 100;
    
    private static int hashCode(String input) {
        if (input.length() != 6) {
            return -1;
        }
        int result = 0;
        for (int i=0; i<input.length(); i++) {
            result += input.charAt(i);
        }
        return result % LENGTH;
    }
    
    public MyHashTable() {
        hashTable = new AVLTree[LENGTH];
        for (int i=0; i<LENGTH; i++) {
            hashTable[i] = new AVLTree();
        }
        //hashTable = (AVLTree<T>[])(new Object[LENGTH]);
    }
    public AVLTree at(int index) {
        return hashTable[index];
    }
    
    public void add(String input, int stringNumber) {
        if (hashTable == null) {
            return;
        }
        
        if (input.length() < 6) {
            return;
        }
        
        for (int i=0; i<input.length() - 5; i++) {
            String target = input.substring(i, i+6);
            int hashCode = hashCode(target);
            //stringNumber and i both starts at 0!!
            hashTable[hashCode].insert(target, stringNumber + 1, i + 1);
            //now converted to 'start at 1' index
        }
    }
    
    public String search(String input) {
        if (input.length() < 6) return null;
        StringBuilder sb = new StringBuilder();
        int hashCode = 0;
        
        String targetString;
        int substringCounter = input.length() - 5;
        
        MyLinkedList[] coordArray = new MyLinkedList[substringCounter];
        
        for (int i=0; i<substringCounter; i++) {
            targetString = input.substring(i, i+6);
            hashCode = hashCode(targetString);
            
            AVLTree targetTree = hashTable[hashCode];
            if (targetTree == null) return null;
            
            AVLNode targetNode = targetTree.explicitSearch(targetString);
            if (targetNode == null) return null;
            
            coordArray[i] = targetNode.getCoordList();
            if (coordArray[i] == null) return null;
        }
        
        MyLinkedList firstCoordList = new MyLinkedList(coordArray[0]);
        
        for (int i=1; i<substringCounter; i++) {
            //if (!coordArray[i].equals(firstCoordList, i)) {
            // AND operation
            firstCoordList = firstCoordList.and(coordArray[i], i);
            //}
            if (firstCoordList == null) {
                return null;
            }
        }
        
        sb.append(firstCoordList.toString());
        
        if (sb.length() == 0) {
            return null;
            //sb.append("(0, 0)");
        }
        
        return sb.toString();
    }
}