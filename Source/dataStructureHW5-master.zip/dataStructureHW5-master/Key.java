public class Key implements Comparable<Key> {
    private int stringNumber;
    private int startIndex;
    
    public Key(int stringNumber, int startIndex) {
        this.stringNumber = stringNumber;
        this.startIndex = startIndex;
    }
    
    public Key(Key rhs) {
        this.stringNumber = rhs.stringNumber;
        this.startIndex = rhs.startIndex;
    }
    
    public int getStringNumber() {
        return this.stringNumber;
    }
    
    public int getStartIndex() {
        return this.startIndex;
    }
    
    public int compareTo(Key rhs) {
        if (this.stringNumber > rhs.stringNumber) {
            return 1;
        }
        if (this.stringNumber < rhs.stringNumber) {
            return -1;
        }
        
        if (startIndex > rhs.startIndex) {
            return 1;
        }
        
        if (startIndex < rhs.startIndex) {
            return -1;
        }
        
        return 0;
    }
    
    public boolean equals(Key rhs) {
        return this.compareTo(rhs) == 0;
    }
    
    public boolean equals(Key rhs, int shift) {
        if (stringNumber != rhs.stringNumber) {
            return false;
        }
        
        return (startIndex == (rhs.startIndex + shift));
    }
}