public class AVLTree {
    private AVLNode dummy;
    
    public AVLTree() {
        dummy = new AVLNode(null, new Key(0, 0));
    }
    
    public AVLTree(AVLNode head) {
        //dummy's left child is AVLTree start.
        dummy = new AVLNode(null, null, head, new Key(0, 0));
    }
    
    public int getHeight() {
        return dummy.getHeight()-1;
    }
    
    //rotate : call when target.needRotation() is true
    public void rotate(AVLNode target) {
        AVLNode targetParent = target.getParent();
        boolean isRight;
        if (targetParent.getLeft() == target) {
            isRight = false;
        } else if (targetParent.getRight() == target) {
            isRight = true;
        } else {
            System.out.println("ROTATE() ERROR : inappropriate parent");
            return;
        }
        
        if (target.needRightRotation()) {
            AVLNode targetLeft = target.getLeft();
            // NullPointerException resolved?
            if (targetLeft.getRight() == null || targetLeft.getLeft() != null &&
                targetLeft.getLeft().getHeight() > targetLeft.getRight().getHeight()) {
                //LL case
                
                targetParent.connect(targetLeft, isRight);
                target.connect(targetLeft.getRight(), false);
                targetLeft.connect(target, true);
                
                targetLeft.getLeft().setHeight();
                target.setHeight();
                targetLeft.setHeight();
            } else {
                //LR case
                AVLNode LR = targetLeft.getRight();
                
                targetParent.connect(LR, isRight);
                targetLeft.connect(LR.getLeft(), true);
                target.connect(LR.getRight(), false);
                LR.connect(targetLeft, false);
                LR.connect(target, true);
                
                target.setHeight();
                targetLeft.setHeight();
                LR.setHeight();
            }
        } else if (target.needLeftRotation()) {
            AVLNode targetRight = target.getRight();
            // resolved?
            if (targetRight.getRight() == null || targetRight.getLeft() != null &&
                targetRight.getLeft().getHeight() > targetRight.getRight().getHeight()) {
                //RL case
                AVLNode RL = targetRight.getLeft();
                
                targetParent.connect(RL, isRight);
                target.connect(RL.getLeft(), true);
                targetRight.connect(RL.getRight(), false);
                RL.connect(target, false);
                RL.connect(targetRight, true);

                target.setHeight();
                targetRight.setHeight();
                RL.setHeight();
            } else {
                //RR case
                targetParent.connect(targetRight, isRight);
                target.connect(targetRight.getLeft(), true);
                targetRight.connect(target, false);

                targetRight.getRight().setHeight();
                target.setHeight();
                targetRight.setHeight();
            }
        } else {
            //inappropriate method call
            System.out.println("INAPPROPRIATE ROTATE() CALL");
            return;
        }
    }
    
    //insert : if already exist, insert coord.
    public void insert(String t, int stringNumber, int startIndex) {
        AVLNode searchResult = search(t);
        
        if (searchResult == null) {
            dummy.setLeft(new AVLNode(t, dummy, new Key(stringNumber, startIndex)));
            searchResult = dummy.getLeft();
            return;
        }
        
        if (searchResult.getItem().compareTo(t) > 0) {
            searchResult.setLeft(new AVLNode(t, searchResult, new Key(stringNumber, startIndex)));
        } else if (searchResult.getItem().compareTo(t) < 0) {
            searchResult.setRight(new AVLNode(t, searchResult, new Key(stringNumber, startIndex)));
        } else {//already exist
            searchResult.getCoordList().insert(new Key(stringNumber, startIndex));
            return;
        }
        
        //update height information & do rotation when needed
        AVLNode cursor = searchResult;
        while (cursor != dummy) {
            cursor.setHeight();
            if (cursor.needRotation()) {
                this.rotate(cursor);
                break;//??
            }
            cursor = cursor.getParent();
        }
    }
    
    //search : return last reference if not found
    //          if found, return reference of that
    //          return null when tree is empty
    public AVLNode search(String t) {
        AVLNode prev = dummy;
        AVLNode curr;
        
        if (dummy.getLeft() == null) {
            return null;
        } else {
            curr = dummy.getLeft();
        }
        
        while (curr.getItem().compareTo(t) != 0) {
            prev = curr;
            
            if (curr.getItem().compareTo(t) > 0) {
                curr = curr.getLeft();
            } else {
                curr = curr.getRight();
            }
            
            if (curr == null) {
                return prev;
            }
        }
        return curr;
    }
    
    //return null when not found or tree is empty
    public AVLNode explicitSearch(String input) {
        AVLNode curr;
        
        if (dummy.getLeft() == null) {
            return null;
        } else {
            curr = dummy.getLeft();
        }
        
        while (curr.getItem().compareTo(input) != 0) {
            
            if (curr.getItem().compareTo(input) > 0) {
                curr = curr.getLeft();
            } else {
                curr = curr.getRight();
            }
            
            if (curr == null) {
                return null;
            }
        }
        return curr;
    }

    //when tree is empty, do nothing
    // when item not found, do nothing
    // when item found, delete
    public void delete(String t) {
        AVLNode target = search(t);
        
        if (target == null) {
            return;
        }
        
        if (target.getItem().compareTo(t) == 0) {
            //deletion process
            AVLNode replace = getMost(target.getLeft());
            AVLNode replaceParent = replace.getParent();
            target.setItem(replace.getItem());
            replaceParent.setRight(replace.getLeft());
            
            AVLNode cursor = replaceParent;
            while (cursor != dummy) {
                cursor.setHeight();
                if (cursor.needRotation()) {
                    rotate(cursor);
                    break;
                }
                cursor = cursor.getParent();
            }
        } else {
            return;
        }
    }
    
    public AVLNode getMost(AVLNode cursor) {
        while (cursor.getRight() != null) {
            cursor = cursor.getRight();
        }
        return cursor;
    }
    
    public void preorderPrint() {
        if (dummy.getLeft() == null) {
            System.out.println("EMPTY");
            return;
        }
        StringBuilder sb = new StringBuilder();
        preorderRecursivePrint(dummy.getLeft(), sb);
        sb.delete(sb.length() - 1, sb.length());
        System.out.println(sb);
    }
    
    public void preorderRecursivePrint(AVLNode curr, StringBuilder sb) {
        if (curr == null) {
            return;
        }
        sb.append(curr.getItem() + " ");
        preorderRecursivePrint(curr.getLeft(), sb);
        preorderRecursivePrint(curr.getRight(), sb);
    }
}