public class AVLNode {
    private MyLinkedList coordList;
    
    private String item;
    private AVLNode parent;
    private AVLNode left;
    private AVLNode right;
    private int height = 0;
    
    //implement stringNumber & stringIndex!!
    public AVLNode(String item, Key key) {
        coordList = new MyLinkedList();
        coordList.insert(key);
        this.item = item;
        parent = null;
        left = null;
        right = null;
        height = 1;
    }
    
    public AVLNode(String item, AVLNode parent, Key key) {
        coordList = new MyLinkedList();
        coordList.insert(key);
        this.item = item;
        this.parent = parent;
        this.left = null;
        this.right = null;
        this.height = 1;
    }
    
    public AVLNode(String item, AVLNode parent, AVLNode left, Key key) {
        coordList = new MyLinkedList();
        coordList.insert(key);
        this.item = item;
        this.parent = parent;
        this.left = left;
        this.right = null;
        this.height = left.height + 1;
    }
    
    public AVLNode(String item, AVLNode parent, AVLNode left, AVLNode right, Key key) {
        coordList = new MyLinkedList();
        coordList.insert(key);
        this.item = item;
        this.parent = parent;
        this.left = left;
        this.right = right;
        this.height = (left.height > right.height) ? left.height + 1 : right.height + 1;
    }
    
    public boolean equals(AVLNode rhs) {
        if (rhs == null) return false;
        if (!this.item.equals(rhs.item)) {
            return false;
        }
        
        return true;
    }
    
    //public boolean equals(AVLNode rhs, int shift) {
    //    if (rhs == null) return false;
    //    return this.coordList.equals(rhs.getCoordList(), shift);
    //}
    
    public void connect(AVLNode child, boolean isRight) {
        if (child != null) {
            child.setParent(this);
        }
        
        if (isRight) {
            this.setRight(child);
        } else {
            this.setLeft(child);
        }
    }
    
    public void swap(AVLNode lhs, AVLNode rhs) {
        MyLinkedList tmp = lhs.coordList;
        lhs.coordList = rhs.coordList;
        rhs.coordList = tmp;
        
        String temp = lhs.item;
        lhs.item = rhs.item;
        rhs.item = temp;
    }
    
    public MyLinkedList getCoordList() {
        return this.coordList;
    }
    
    public String getItem() {
        return item;
    }
    
    public int getHeight() {
        return height;
    }
    
    public AVLNode getParent() {
        return parent;
    }
    
    public AVLNode getLeft() {
        return left;
    }
    
    public AVLNode getRight() {
        return right;
    }
    
    public void setItem(String item) {
        if (item != null) {
            this.item = item;
        }
    }
    
    public void setHeight() {
        if (left == null && right == null) {
            height = 1;
        } else if (left == null) {
            height = right.getHeight() + 1;
        } else if (right == null) {
            height = left.getHeight() + 1;
        } else {
            height = left.getHeight() > right.getHeight() ?
                    left.getHeight() + 1 : right.getHeight() + 1;
        }
        
    }
    
    public void setHeight(int height) {
        this.height = height;
    }
    
    public void setParent(AVLNode parent) {
        this.parent = parent;
    }
    
    public void setLeft(AVLNode left) {
        if (left != null) {
            left.setParent(this);
        }
        this.left = left;
    }
    
    public void setRight(AVLNode right) {
        if (right != null) {
            right.setParent(this);
        }
        this.right = right;
    }
    
    public boolean needRotation() {
        return this.needRightRotation() || this.needLeftRotation();
    }
    public boolean needRightRotation() {
        //error handling for dummy head
        if (parent == null) {
            return false;
        }
        if (left == null && right == null) {
            return false;
        } else if (left == null) {
            return false;
        } else if (right == null) {
            return left.height > 1;
        }
        return left.height - right.height > 1;
    }
    public boolean needLeftRotation() {
        if (parent == null) {
            return false;
        }
        if (left == null && right == null) {
            return false;
        } else if (left == null) {
            return right.height > 1;
        } else if (right == null) {
            return false;
        }
        return right.height - left.height > 1;
    }
}