import java.io.*;

public class Matching {
	private static String textContent;
	private static int stringCounter;
	private static String[] string;
	private static MyHashTable hashTable;
	
	public static void main(String args[]) {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		while (true) {
			try {
				String input = br.readLine();
				//input = input.toUpperCase();??
				if (input.compareTo("QUIT") == 0)
					break;

				command(input);
			}
			catch (IOException e){
				System.out.println("입력이 잘못되었습니다. 오류 : " + e.toString());
			}
		}
	}

	private static void command(String input) {
		
		switch(input.charAt(0)) {
			case '<'://text file input
				Reader reader;
				StringBuilder sb = new StringBuilder();
				try {
					reader = new FileReader(input.substring(2, input.length()));
                    
                    char[] temp = new char[1000];
                    stringCounter = 1;
                    int readLength;
                    int prevReadLength = 0;
                    
                    while ((readLength = reader.read(temp)) != -1) {
                        sb.append(temp);
                        for (int i=0; i < readLength; i++) {
                            if (temp[i] == '\n') {
                                stringCounter++;
                            }
                        }
                        prevReadLength = readLength;
                    }
                    sb.delete(sb.length() - (1000 - prevReadLength), sb.length());
                } catch (Exception e) {
                    System.err.println(e.toString());
                    return;
                }
                
                textContent = sb.toString();
                string = new String[stringCounter];
                
                int j=0, k=0;
                for (int i=0; i<textContent.length(); i++) {
                    if (textContent.charAt(i) == '\n') {
                        string[j++] = new String(textContent.substring(k, i));
                        k = i + 1;
                    }
                }
                string[j] = new String(textContent.substring(k, textContent.length()));
                hashTable = new MyHashTable();
                
                for (int i=0; i<stringCounter; i++) {
                    hashTable.add(string[i], i);
                }
			break;
			case '@'://@(index number)
				int index = Integer.parseInt(input.substring(2, input.length()));
				hashTable.at(index).preorderPrint();
			break;
			case '?'://?(pattern) 패턴 문자열 길이는 6 이상
				String what = input.substring(2, input.length());
				String result;
				if ((result = hashTable.search(what)) == null) {
					System.out.println("(0, 0)");
				} else {
					System.out.println(result);
				}
			break;
			default:
				System.out.println("입력이 잘못되었습니다.");
			break;
		}
	}
}